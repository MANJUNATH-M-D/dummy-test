-- ============================================================
--  JSW Paints — Supabase database setup
--  HOW TO USE:
--  1. In your Supabase project, open the left menu -> "SQL Editor"
--  2. Click "New query"
--  3. Copy EVERYTHING in this file and paste it into the editor
--  4. Click the green "Run" button
--  You should see "Success. No rows returned." -> that means it worked.
-- ============================================================

-- ---------- PRODUCTS (your stock) ----------
create table if not exists products (
  barcode   text primary key,
  name      text not null,
  cat       text,
  cost      numeric default 0,
  price     numeric default 0,
  gst       numeric default 18,
  qty       integer default 0,
  low       integer default 5,
  created_at timestamptz default now()
);

-- ---------- CUSTOMERS ----------
create table if not exists customers (
  mobile    text primary key,
  name      text not null,
  orders    integer default 0,
  spent     numeric default 0,
  last      bigint default 0
);

-- ---------- REFERRAL PERSONS ----------
create table if not exists referrals (
  name      text primary key
);

-- ---------- STOCK MOVEMENTS (in / out log) ----------
create table if not exists movements (
  id        bigint generated always as identity primary key,
  ts        bigint,
  barcode   text,
  name      text,
  type      text,        -- 'in' or 'out'
  qty       integer,
  note      text
);

-- ---------- BILLS (sales) ----------
create table if not exists bills (
  no         integer primary key,
  ts         bigint,
  custmobile text,
  custname   text,
  type       text,        -- 'gst' or 'nogst'
  items      jsonb,       -- list of items sold
  subtotal   numeric,
  discount   numeric,
  gstamt     numeric,
  total      numeric,
  refer      text
);

-- ---------- BILL COUNTER (next bill number) ----------
create table if not exists counters (
  id        text primary key,
  value     integer
);
insert into counters (id, value) values ('billSeq', 1)
on conflict (id) do nothing;

-- ============================================================
--  SECURITY (Row Level Security)
--  This makes the tables readable/writable by your app's
--  public key. For a single-shop tool this is fine.
-- ============================================================
alter table products  enable row level security;
alter table customers enable row level security;
alter table referrals enable row level security;
alter table movements enable row level security;
alter table bills     enable row level security;
alter table counters  enable row level security;

-- Allow the anon (public) key full access. Re-runnable safely.
do $$
declare t text;
begin
  foreach t in array array['products','customers','referrals','movements','bills','counters']
  loop
    execute format('drop policy if exists "allow all %1$s" on %1$s;', t);
    execute format('create policy "allow all %1$s" on %1$s for all using (true) with check (true);', t);
  end loop;
end $$;
