/* ============================================================
   YOUR SUPABASE KEYS — edit the two lines below.
   ------------------------------------------------------------
   Where to find these:
   1. Open your project at supabase.com
   2. Click the gear icon (Project Settings) at the bottom-left
   3. Click "API" in the settings menu
   4. Copy "Project URL"  -> paste between the quotes in SUPABASE_URL
   5. Copy the "anon public" key -> paste into SUPABASE_KEY
   ============================================================ */

const SUPABASE_URL = "PASTE_YOUR_PROJECT_URL_HERE";
const SUPABASE_KEY = "PASTE_YOUR_ANON_PUBLIC_KEY_HERE";
