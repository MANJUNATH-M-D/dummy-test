/* =========================================================
   JSW Paints — Stock & Sales Manager
   CLOUD VERSION — data stored in Supabase
   ========================================================= */

/* ---------- connect to Supabase ---------- */
let sb = null;
let CLOUD_OK = false;
try {
  if (SUPABASE_URL && SUPABASE_KEY && !SUPABASE_URL.includes("PASTE_")) {
    sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
    CLOUD_OK = true;
  }
} catch (e) { CLOUD_OK = false; }

/* in-memory copy of all data (filled from cloud on load) */
let state = { products:[], movements:[], customers:[], referrals:[], bills:[], billSeq:1 };

const $=id=>document.getElementById(id);
const money=n=>'₹'+(Number(n)||0).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
const money0=n=>'₹'+Math.round(Number(n)||0).toLocaleString('en-IN');
function toast(msg,bad){const t=$('toast');t.textContent=msg;t.className='show'+(bad?' bad':'');setTimeout(()=>t.className='',2400)}
function setSync(text,cls){const b=$('syncBadge');if(b){b.textContent=text;b.className='sync '+(cls||'')}}

/* ---------- date helpers ---------- */
const dayKey=d=>{d=new Date(d);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const isSameDay=(a,b)=>dayKey(a)===dayKey(b);
function fmtDate(d){d=new Date(d);return d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}
function fmtTime(d){d=new Date(d);return d.toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}
function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

/* ====================================================
   CLOUD LOAD  — pull everything from Supabase
   ==================================================== */
async function loadAll(){
  if(!CLOUD_OK){
    setSync('⚠ Not configured','bad');
    toast('Open config.js and paste your Supabase URL + key',1);
    return;
  }
  setSync('Loading…','');
  try{
    const [prod,cust,refs,mov,bills,ctr] = await Promise.all([
      sb.from('products').select('*').order('name'),
      sb.from('customers').select('*'),
      sb.from('referrals').select('*').order('name'),
      sb.from('movements').select('*').order('ts',{ascending:false}).limit(200),
      sb.from('bills').select('*').order('no',{ascending:false}),
      sb.from('counters').select('*').eq('id','billSeq').single()
    ]);
    if(prod.error||cust.error||refs.error||mov.error||bills.error) throw (prod.error||cust.error||refs.error||mov.error||bills.error);

    state.products  = prod.data || [];
    state.customers = cust.data || [];
    state.referrals = (refs.data||[]).map(r=>r.name);
    state.movements = mov.data || [];
    // map db column names (lowercase) back to app field names
    state.bills = (bills.data||[]).map(b=>({
      no:b.no, ts:Number(b.ts), custMobile:b.custmobile, custName:b.custname,
      type:b.type, items:b.items, subtotal:Number(b.subtotal), discount:Number(b.discount),
      gstAmt:Number(b.gstamt), total:Number(b.total), refer:b.refer
    }));
    state.billSeq = (ctr.data && ctr.data.value) || 1;

    setSync('☁ Cloud connected','ok');
    renderAll();
  }catch(e){
    console.error(e);
    setSync('⚠ Connection failed','bad');
    toast('Could not reach database. Check internet / keys / SQL setup.',1);
  }
}

/* small helpers to write to cloud and show errors */
async function cloudUpsert(table,row){
  const {error}=await sb.from(table).upsert(row);
  if(error){console.error(error);toast('Save failed: '+error.message,1);return false}
  return true;
}
async function cloudDelete(table,col,val){
  const {error}=await sb.from(table).delete().eq(col,val);
  if(error){console.error(error);toast('Delete failed: '+error.message,1);return false}
  return true;
}

/* ---------- navigation ---------- */
$('nav').addEventListener('click',e=>{
  const b=e.target.closest('button[data-view]'); if(!b)return;
  document.querySelectorAll('nav button').forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));
  $(b.dataset.view).classList.add('active');
  renderAll();
});

/* ====================================================
   PRODUCTS / STOCK
   ==================================================== */
function findProduct(code){ return state.products.find(p=>p.barcode===code.trim()) }

$('genBarcode').onclick=()=>{ $('pBarcode').value='JSW'+Date.now().toString().slice(-9) };

$('saveProduct').onclick=async()=>{
  const code=$('pBarcode').value.trim();
  const name=$('pName').value.trim();
  if(!code){return toast('Enter or scan a barcode',1)}
  if(!name){return toast('Enter a product name',1)}
  const data={
    barcode:code, name,
    cat:$('pCat').value.trim(),
    cost:parseFloat($('pCost').value)||0,
    price:parseFloat($('pPrice').value)||0,
    gst:parseFloat($('pGst').value)||0,
    qty:parseInt($('pQty').value)||0,
    low:parseInt($('pLow').value)||5
  };
  const ok=await cloudUpsert('products',data);
  if(!ok)return;
  const ex=findProduct(code);
  if(ex){Object.assign(ex,data);toast('Product updated')}
  else{state.products.push(data);toast('Product added')}
  ['pBarcode','pName','pCat','pCost','pPrice','pQty'].forEach(i=>$(i).value='');
  $('pGst').value=18; $('pLow').value=5;
  renderAll();
};

$('pBarcode').addEventListener('change',()=>{
  const p=findProduct($('pBarcode').value);
  if(p){$('pName').value=p.name;$('pCat').value=p.cat;$('pCost').value=p.cost;$('pPrice').value=p.price;$('pGst').value=p.gst;$('pLow').value=p.low;toast('Existing item loaded — editing')}
});

$('mvBarcode').addEventListener('input',()=>{
  const p=findProduct($('mvBarcode').value);
  $('mvFound').textContent = p ? `✓ ${p.name} — current qty ${p.qty}` : 'No item selected.';
  $('mvFound').style.color = p ? 'var(--ok)' : 'var(--muted)';
});
$('mvBarcode').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('applyMove').click()}});

$('applyMove').onclick=async()=>{
  const p=findProduct($('mvBarcode').value);
  if(!p){return toast('Scan a valid barcode first',1)}
  const qty=parseInt($('mvQty').value)||0;
  if(qty<=0){return toast('Quantity must be at least 1',1)}
  const type=$('mvType').value;
  if(type==='out' && qty>p.qty){return toast('Not enough stock to remove',1)}
  const newQty=p.qty+(type==='in'?qty:-qty);
  const mv={ts:Date.now(),barcode:p.barcode,name:p.name,type,qty,note:$('mvNote').value.trim()};
  const ok=await cloudUpsert('products',{...p,qty:newQty});
  if(!ok)return;
  await sb.from('movements').insert(mv);
  p.qty=newQty;
  state.movements.unshift(mv);
  toast(`Stock ${type==='in'?'added':'removed'}: ${qty} × ${p.name}`);
  $('mvBarcode').value='';$('mvQty').value=1;$('mvNote').value='';$('mvFound').textContent='No item selected.';$('mvFound').style.color='var(--muted)';
  renderAll();
};

function renderStockTable(){
  const q=($('stockSearch').value||'').toLowerCase();
  const rows=state.products
    .filter(p=>p.name.toLowerCase().includes(q)||p.barcode.toLowerCase().includes(q))
    .map(p=>{
      const low=p.qty<=p.low;
      return `<tr>
        <td class="barcode">${p.barcode}</td>
        <td><strong>${esc(p.name)}</strong></td>
        <td>${esc(p.cat||'—')}</td>
        <td><strong>${p.qty}</strong></td>
        <td>${money(p.price)}</td>
        <td>${p.gst}%</td>
        <td><span class="pill ${low?'low':'ok'}">${low?'LOW':'OK'}</span></td>
        <td><button class="btn ghost sm" onclick="editProduct('${p.barcode}')">Edit</button>
            <button class="btn danger sm" onclick="delProduct('${p.barcode}')">Del</button></td>
      </tr>`;
    }).join('');
  $('stockTable').innerHTML = rows || `<tr><td colspan="8" class="empty">No products yet. Add your first item above.</td></tr>`;
}
window.editProduct=code=>{
  const p=findProduct(code); if(!p)return;
  $('pBarcode').value=p.barcode;$('pName').value=p.name;$('pCat').value=p.cat;$('pCost').value=p.cost;
  $('pPrice').value=p.price;$('pGst').value=p.gst;$('pQty').value=p.qty;$('pLow').value=p.low;
  window.scrollTo({top:0,behavior:'smooth'});toast('Loaded for editing');
};
window.delProduct=async code=>{
  if(!confirm('Delete this product?'))return;
  const ok=await cloudDelete('products','barcode',code); if(!ok)return;
  state.products=state.products.filter(p=>p.barcode!==code);renderAll();toast('Product deleted');
};
$('stockSearch').oninput=renderStockTable;

function renderMoveLog(){
  $('moveLog').innerHTML = state.movements.slice(0,40).map(m=>`<tr>
    <td>${fmtTime(m.ts)}</td><td>${esc(m.name)}</td>
    <td><span class="pill ${m.type==='in'?'ok':'low'}">${m.type==='in'?'IN':'OUT'}</span></td>
    <td>${m.qty}</td><td>${esc(m.note||'—')}</td></tr>`).join('')
    || `<tr><td colspan="5" class="empty">No movements logged yet.</td></tr>`;
}

/* ====================================================
   SALE / CART
   ==================================================== */
let cart=[];
function addToCart(code){
  const p=findProduct(code.trim());
  if(!p){return toast('Barcode not found in stock',1)}
  if(p.qty<=0){return toast(`${p.name} is out of stock`,1)}
  const line=cart.find(c=>c.barcode===p.barcode);
  if(line){
    if(line.qty>=p.qty){return toast('Reached available stock for this item',1)}
    line.qty++;
  } else {
    cart.push({barcode:p.barcode,name:p.name,price:p.price,gst:p.gst,qty:1});
  }
  renderCart();toast(`Added ${p.name}`);
}
$('saleAddBtn').onclick=()=>{const v=$('saleScan').value;if(v.trim()){addToCart(v);$('saleScan').value='';$('saleScan').focus()}};
$('saleScan').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('saleAddBtn').click()}});

window.cartQty=(i,v)=>{
  const c=cart[i]; const p=findProduct(c.barcode);
  let q=parseInt(v)||0;
  if(q<1)q=1;
  if(p&&q>p.qty){q=p.qty;toast('Limited to available stock',1)}
  c.qty=q;renderCart();
};
window.cartDel=i=>{cart.splice(i,1);renderCart()};

function computeTotals(){
  const withGst = $('billType').value==='gst';
  let subtotal=0, gstAmt=0;
  cart.forEach(c=>{subtotal+=c.price*c.qty});
  let disc=0;
  const dv=parseFloat($('discVal').value)||0;
  if($('discType').value==='pct') disc=subtotal*dv/100; else disc=dv;
  if(disc>subtotal)disc=subtotal;
  const taxable=subtotal-disc;
  if(withGst){
    cart.forEach(c=>{
      const lineNet=c.price*c.qty;
      const share=subtotal>0?lineNet/subtotal:0;
      gstAmt+=(taxable*share)*(c.gst/100);
    });
  }
  return {withGst,subtotal,disc,gstAmt,taxable,total:taxable+gstAmt};
}

function renderCart(){
  $('cartEmpty').style.display=cart.length===0?'block':'none';
  $('cart').innerHTML=cart.map((c,i)=>`
    <div class="cart-line">
      <div class="nm">${esc(c.name)}<br><span class="barcode" style="font-size:11px">${c.barcode}</span></div>
      <div><input type="number" min="1" value="${c.qty}" onchange="cartQty(${i},this.value)"></div>
      <div class="price-col" style="text-align:right">${money(c.price)}</div>
      <div style="text-align:right;font-weight:700">${money(c.price*c.qty)}</div>
      <div><button class="btn danger sm" onclick="cartDel(${i})">✕</button></div>
    </div>`).join('');
  const t=computeTotals();
  $('cSub').textContent=money(t.subtotal);
  $('cDisc').textContent='−'+money(t.disc);
  $('cGst').textContent=money(t.gstAmt);
  $('cGstLine').style.display=t.withGst?'flex':'none';
  $('cTotal').textContent=money(t.total);
}
['billType','discType','discVal'].forEach(id=>$(id).addEventListener('input',renderCart));
$('clearCart').onclick=()=>{cart=[];$('discVal').value=0;renderCart();toast('Cart cleared')};

$('lookupCust').onclick=()=>{
  const m=$('custMobile').value.trim();
  const c=state.customers.find(x=>x.mobile===m);
  if(c){$('custName').value=c.name;toast('Customer found')}else toast('New customer — enter name',0);
};

/* generate bill — writes bill, updates stock, customer & counter in cloud */
$('generateBill').onclick=async()=>{
  if(cart.length===0){return toast('Cart is empty',1)}
  if(!CLOUD_OK){return toast('Database not configured',1)}
  const mobile=$('custMobile').value.trim();
  const name=$('custName').value.trim()||'Walk-in';
  const t=computeTotals();
  const billNo=state.billSeq;

  setSync('Saving sale…','');

  // 1) write the bill (db uses lowercase column names)
  const billRow={
    no:billNo, ts:Date.now(), custmobile:mobile, custname:name,
    type:t.withGst?'gst':'nogst', items:cart.map(c=>({...c})),
    subtotal:t.subtotal, discount:t.disc, gstamt:t.gstAmt, total:t.total,
    refer:$('referBy').value
  };
  const {error:be}=await sb.from('bills').insert(billRow);
  if(be){console.error(be);setSync('⚠ Save failed','bad');return toast('Could not save bill: '+be.message,1)}

  // 2) deduct stock + log movements
  for(const c of cart){
    const p=findProduct(c.barcode);
    if(p){
      const nq=p.qty-c.qty;
      await sb.from('products').update({qty:nq}).eq('barcode',p.barcode);
      await sb.from('movements').insert({ts:Date.now(),barcode:p.barcode,name:p.name,type:'out',qty:c.qty,note:'Sale #'+billNo});
      p.qty=nq;
      state.movements.unshift({ts:Date.now(),barcode:p.barcode,name:p.name,type:'out',qty:c.qty,note:'Sale #'+billNo});
    }
  }

  // 3) customer record
  if(mobile){
    let c=state.customers.find(x=>x.mobile===mobile);
    if(!c){c={mobile,name,orders:0,spent:0,last:0};state.customers.push(c)}
    c.name=name;c.orders++;c.spent=Number(c.spent)+t.total;c.last=Date.now();
    await sb.from('customers').upsert({mobile:c.mobile,name:c.name,orders:c.orders,spent:c.spent,last:c.last});
  }

  // 4) bump bill counter
  state.billSeq=billNo+1;
  await sb.from('counters').update({value:state.billSeq}).eq('id','billSeq');

  // 5) update local bills + show invoice
  const localBill={no:billNo,ts:billRow.ts,custMobile:mobile,custName:name,type:billRow.type,
    items:billRow.items,subtotal:t.subtotal,discount:t.disc,gstAmt:t.gstAmt,total:t.total,refer:billRow.refer};
  state.bills.unshift(localBill);

  setSync('☁ Cloud connected','ok');
  showInvoice(localBill);
  cart=[];$('custMobile').value='';$('custName').value='';$('discVal').value=0;$('referBy').value='';
  renderCart();renderAll();
};

/* ====================================================
   INVOICE
   ==================================================== */
const SHOP={name:'JSW Paints Dealership',addr:'Shop Address Line 1, City, State - PIN',phone:'+91 00000 00000',gstin:'GSTIN: 00XXXXX0000X0Z0'};
function showInvoice(b){
  const withGst=b.type==='gst';
  const rows=b.items.map((it,i)=>{
    const net=it.price*it.qty;
    return `<tr><td>${i+1}</td><td>${esc(it.name)}<br><span style="color:#888;font-size:10px">${it.barcode}</span></td>
      <td class="r">${it.qty}</td><td class="r">${money(it.price)}</td>
      ${withGst?`<td class="r">${it.gst}%</td>`:''}
      <td class="r">${money(net)}</td></tr>`;
  }).join('');
  $('invoice').innerHTML=`
    <div class="inv-top">
      <div>
        <div class="tag">Tax Invoice</div>
        <h2>${SHOP.name}</h2>
        <div style="font-size:11px;color:#555;margin-top:4px">${SHOP.addr}<br>${SHOP.phone}${withGst?'<br>'+SHOP.gstin:''}</div>
      </div>
      <div class="inv-meta">
        ${withGst?'<span class="badge-gst">GST INVOICE</span>':'<span class="badge-nogst">CASH BILL</span>'}<br>
        <strong>Bill #${String(b.no).padStart(4,'0')}</strong><br>
        ${fmtDate(b.ts)} ${fmtTime(b.ts)}
      </div>
    </div>
    <div class="inv-party">
      <div><strong>Billed To</strong><br>${esc(b.custName)}<br>${b.custMobile?('📱 '+b.custMobile):''}</div>
      <div style="text-align:right">${b.refer?('<strong>Referred By</strong><br>'+esc(b.refer)):''}</div>
    </div>
    <table class="inv">
      <thead><tr><th>#</th><th>Item</th><th class="r">Qty</th><th class="r">Rate</th>${withGst?'<th class="r">GST</th>':''}<th class="r">Amount</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
    <div class="inv-tot">
      <div class="l"><span>Subtotal</span><span>${money(b.subtotal)}</span></div>
      <div class="l"><span>Discount</span><span>−${money(b.discount)}</span></div>
      ${withGst?`<div class="l"><span>GST</span><span>${money(b.gstAmt)}</span></div>`:''}
      <div class="l g"><span>Grand Total</span><span>${money(b.total)}</span></div>
    </div>
    <div class="inv-foot">
      <span>Goods once sold are not returnable. E.&amp;O.E.</span>
      <span>Thank you for your business!</span>
    </div>`;
  $('billOverlay').classList.add('show');
}
$('closeBill').onclick=$('closeBill2').onclick=()=>$('billOverlay').classList.remove('show');
$('printBill').onclick=()=>window.print();
window.viewBill=no=>{const b=state.bills.find(x=>x.no===no);if(b)showInvoice(b)};

/* ====================================================
   CUSTOMERS & REFERRALS
   ==================================================== */
$('addCustomer').onclick=async()=>{
  const name=$('cuName').value.trim(),mobile=$('cuMobile').value.trim();
  if(!name||!mobile){return toast('Enter name and mobile',1)}
  if(state.customers.find(c=>c.mobile===mobile)){return toast('Mobile already exists',1)}
  const row={mobile,name,orders:0,spent:0,last:0};
  const ok=await cloudUpsert('customers',row); if(!ok)return;
  state.customers.push(row);
  $('cuName').value='';$('cuMobile').value='';renderAll();toast('Customer added');
};
$('addReferral').onclick=async()=>{
  const n=$('refName').value.trim();
  if(!n){return toast('Enter a referral name',1)}
  if(state.referrals.includes(n)){return toast('Already exists',1)}
  const ok=await cloudUpsert('referrals',{name:n}); if(!ok)return;
  state.referrals.push(n);$('refName').value='';renderAll();toast('Referral added');
};
window.delReferral=async n=>{
  const ok=await cloudDelete('referrals','name',n); if(!ok)return;
  state.referrals=state.referrals.filter(r=>r!==n);renderAll();
};
function renderReferrals(){
  $('refList').innerHTML = state.referrals.length
    ? state.referrals.map(r=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:7px 10px;border:1px solid var(--line);border-radius:7px;margin-bottom:6px;font-size:13px">
        <span>${esc(r)}</span><button class="btn danger sm" onclick="delReferral('${esc(r)}')">✕</button></div>`).join('')
    : `<div class="empty" style="padding:14px">No referral persons yet.</div>`;
  const sel=$('referBy');const cur=sel.value;
  sel.innerHTML='<option value="">— None —</option>'+state.referrals.map(r=>`<option value="${esc(r)}">${esc(r)}</option>`).join('');
  sel.value=cur;
}
function renderCustomers(){
  const q=($('custSearch').value||'').toLowerCase();
  const rows=state.customers
    .filter(c=>c.name.toLowerCase().includes(q)||String(c.mobile).includes(q))
    .sort((a,b)=>b.last-a.last)
    .map(c=>`<tr>
      <td><strong>${esc(c.name)}</strong></td><td class="barcode">${c.mobile}</td>
      <td>${c.orders}</td><td>${money(c.spent)}</td><td>${c.last?fmtDate(c.last):'—'}</td>
      <td><button class="btn danger sm" onclick="delCust('${c.mobile}')">Del</button></td></tr>`).join('');
  $('custTable').innerHTML=rows||`<tr><td colspan="6" class="empty">No customers yet.</td></tr>`;
}
window.delCust=async m=>{
  if(!confirm('Delete customer?'))return;
  const ok=await cloudDelete('customers','mobile',m); if(!ok)return;
  state.customers=state.customers.filter(c=>c.mobile!==m);renderAll();
};
$('custSearch').oninput=renderCustomers;

/* ====================================================
   REPORTS & CHARTS
   ==================================================== */
function salesByDay(){
  const map={};
  state.bills.forEach(b=>{const k=dayKey(b.ts);if(!map[k])map[k]={total:0,bills:0,units:0};
    map[k].total+=b.total;map[k].bills++;map[k].units+=b.items.reduce((s,i)=>s+i.qty,0)});
  return map;
}
function buildSeries(range){
  const byDay=salesByDay();const out=[];const now=new Date();
  if(range==='daily'){
    for(let i=13;i>=0;i--){const d=new Date(now);d.setDate(d.getDate()-i);const k=dayKey(d);
      const v=byDay[k]||{total:0,bills:0,units:0};
      out.push({label:d.toLocaleDateString('en-IN',{day:'2-digit',month:'short'}),...v})}
  } else if(range==='weekly'){
    for(let w=7;w>=0;w--){let total=0,bills=0,units=0;const end=new Date(now);end.setDate(end.getDate()-w*7);
      const start=new Date(end);start.setDate(start.getDate()-6);
      Object.keys(byDay).forEach(k=>{const d=new Date(k);if(d>=stripTime(start)&&d<=stripTime(end)){total+=byDay[k].total;bills+=byDay[k].bills;units+=byDay[k].units}});
      out.push({label:start.toLocaleDateString('en-IN',{day:'2-digit',month:'short'}),total,bills,units})}
  } else {
    for(let m=5;m>=0;m--){const d=new Date(now.getFullYear(),now.getMonth()-m,1);let total=0,bills=0,units=0;
      Object.keys(byDay).forEach(k=>{const dd=new Date(k);if(dd.getMonth()===d.getMonth()&&dd.getFullYear()===d.getFullYear()){total+=byDay[k].total;bills+=byDay[k].bills;units+=byDay[k].units}});
      out.push({label:d.toLocaleDateString('en-IN',{month:'short',year:'2-digit'}),total,bills,units})}
  }
  return out;
}
const stripTime=d=>{d=new Date(d);d.setHours(0,0,0,0);return d};

function barChart(series,h=300){
  const w=720, pad={l:50,r:14,t:18,b:34};
  const max=Math.max(1,...series.map(s=>s.total));
  const cw=(w-pad.l-pad.r)/series.length;
  const bw=Math.min(46,cw*0.6);const yTicks=4;
  let grid='';
  for(let i=0;i<=yTicks;i++){const val=max*i/yTicks;const y=pad.t+(h-pad.t-pad.b)*(1-i/yTicks);
    grid+=`<line x1="${pad.l}" y1="${y}" x2="${w-pad.r}" y2="${y}" stroke="#E5DFD3"/>
      <text x="${pad.l-8}" y="${y+4}" text-anchor="end" font-size="10" fill="#7A8794">${money0(val)}</text>`}
  let bars='';
  series.forEach((s,i)=>{
    const x=pad.l+cw*i+(cw-bw)/2;
    const bh=(h-pad.t-pad.b)*(s.total/max);const y=h-pad.b-bh;
    bars+=`<rect x="${x}" y="${y}" width="${bw}" height="${Math.max(bh,s.total>0?2:0)}" rx="4" fill="#E4572E">
      <title>${s.label}: ${money(s.total)} • ${s.bills} bills</title></rect>`;
    if(s.total>0)bars+=`<text x="${x+bw/2}" y="${y-5}" text-anchor="middle" font-size="9" fill="#10243B" font-weight="700">${money0(s.total)}</text>`;
    bars+=`<text x="${x+bw/2}" y="${h-pad.b+15}" text-anchor="middle" font-size="9.5" fill="#7A8794">${s.label}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid meet">${grid}${bars}</svg>`;
}

function renderReports(){
  const range=$('repRange').value;
  const series=buildSeries(range);
  $('repChart').innerHTML=barChart(series);
  const total=series.reduce((s,x)=>s+x.total,0);
  const bills=series.reduce((s,x)=>s+x.bills,0);
  const units=series.reduce((s,x)=>s+x.units,0);
  $('rTotal').textContent=money0(total);
  $('rBills').textContent=bills;
  $('rAvg').textContent=money0(bills?total/bills:0);
  $('rUnits').textContent=units;
  $('rPLabel').textContent = range==='daily'?'14-Day Total':range==='weekly'?'8-Week Total':'6-Month Total';
  renderBillTable();
}
$('repRange').onchange=renderReports;

function renderBillTable(){
  $('billTable').innerHTML = state.bills.length ? state.bills.map(b=>`<tr>
    <td><strong>#${String(b.no).padStart(4,'0')}</strong></td>
    <td>${fmtDate(b.ts)}</td>
    <td>${esc(b.custName)}${b.custMobile?'<br><span class="barcode" style="font-size:11px">'+b.custMobile+'</span>':''}</td>
    <td><span class="pill ${b.type==='gst'?'ok':'low'}">${b.type==='gst'?'GST':'NO-GST'}</span></td>
    <td>${b.items.reduce((s,i)=>s+i.qty,0)}</td>
    <td><strong>${money(b.total)}</strong></td>
    <td>${esc(b.refer||'—')}</td>
    <td><button class="btn ghost sm" onclick="viewBill(${b.no})">View</button></td></tr>`).join('')
    : `<tr><td colspan="8" class="empty">No bills generated yet.</td></tr>`;
}

$('exportCsv').onclick=()=>{
  if(!state.bills.length)return toast('No bills to export',1);
  let csv='Bill No,Date,Customer,Mobile,Type,Items,Subtotal,Discount,GST,Total,Referral\n';
  state.bills.slice().reverse().forEach(b=>{
    csv+=[`#${b.no}`,fmtDate(b.ts),`"${b.custName}"`,b.custMobile,b.type,
      b.items.reduce((s,i)=>s+i.qty,0),Number(b.subtotal).toFixed(2),Number(b.discount).toFixed(2),
      Number(b.gstAmt).toFixed(2),Number(b.total).toFixed(2),`"${b.refer||''}"`].join(',')+'\n';
  });
  const blob=new Blob([csv],{type:'text/csv'});const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);a.download='jsw-sales-report.csv';a.click();toast('CSV exported');
};

/* ====================================================
   DASHBOARD
   ==================================================== */
function renderDashboard(){
  $('todayDate').textContent=fmtDate(Date.now());
  const today=state.bills.filter(b=>isSameDay(b.ts,Date.now()));
  $('dTodaySales').textContent=money0(today.reduce((s,b)=>s+b.total,0));
  $('dTodayBills').textContent=today.length;
  $('dItems').textContent=state.products.length;
  $('dUnits').textContent=state.products.reduce((s,p)=>s+p.qty,0);
  $('dashChart').innerHTML=barChart(buildSeries('daily').slice(-7),260);
  const low=state.products.filter(p=>p.qty<=p.low);
  $('lowStock').innerHTML = low.length
    ? low.map(p=>`<div style="display:flex;justify-content:space-between;padding:9px 0;border-bottom:1px solid #EFEBE1">
        <span>${esc(p.name)}</span><span class="pill low">${p.qty} left</span></div>`).join('')
    : `<div class="empty">All items above their alert level. 👍</div>`;
}

function renderAll(){
  renderDashboard();renderStockTable();renderMoveLog();renderCart();
  renderCustomers();renderReferrals();renderReports();
}

/* ---- start: render empty UI, then load from cloud ---- */
renderAll();
loadAll();
