/* ============================================================
   EDITOR PAGE LOGIC
   ============================================================ */
(function () {
  'use strict';

  const DB = window.IVADb;
  const toast = window.IVAToast;

  // ---------- Mount theme toggle ----------
  const themeHost = document.getElementById('theme-toggle-host');
  if (themeHost) themeHost.appendChild(window.IVATheme.buildThemeToggleButton());

  // ---------- Parse slide name ----------
  const params = new URLSearchParams(location.search);
  const SLIDE = params.get('slide');
  if (!SLIDE) {
    alert('No slide specified.');
    location.href = 'index.html';
    return;
  }
  document.getElementById('slide-name').textContent = SLIDE;
  const INDEX_PATH = SLIDE + '/index.html';

  // ---------- State ----------
  let editor = null;
  let originalDoc = null;              // Parsed original index.html (used during load)
  let originalHtmlText = null;         // Authoritative source — used by saveSlide to guarantee head preservation
  const blobUrlMap = new Map();        // blob URL -> DB path (for save-time rewrite)
  const revokeUrls = [];
  let modified = false;
  let currentZoom = 100;
  let codeModalEditor = null;
  let codeModalMode = 'html';
  let selectorCmHtml = null;
  let selectorCmCss = null;

  // ---------- iPad-only devices ----------
  const IPAD_DEVICES = [
    { id: 'ipad-portrait',         name: 'iPad pro — 1366 × 1024',          w: 1366,  h: 1024 },
    { id: 'ipad-landscape',        name: 'iPad — 1024 × 768',          w: 1024, h: 768  },
    { id: 'ipad-mini-portrait',    name: 'iPad Mini — 744 × 1133',     w: 744,  h: 1133 },
    { id: 'ipad-mini-landscape',   name: 'iPad Mini — 1133 × 744',     w: 1133, h: 744  },
    { id: 'ipad-air-portrait',     name: 'iPad Air — 820 × 1180',      w: 820,  h: 1180 },
    { id: 'ipad-air-landscape',    name: 'iPad Air — 1180 × 820',      w: 1180, h: 820  },
    { id: 'ipad-pro11-portrait',   name: 'iPad Pro 11" — 834 × 1194',  w: 834,  h: 1194 },
    { id: 'ipad-pro11-landscape',  name: 'iPad Pro 11" — 1194 × 834',  w: 1194, h: 834  },
    { id: 'ipad-pro13-portrait',   name: 'iPad Pro 12.9" — 1024 × 1366', w: 1024, h: 1366 },
    { id: 'ipad-pro13-landscape',  name: 'iPad Pro 12.9" — 1366 × 1024', w: 1366, h: 1024 }
  ];

  // ---------- UI helpers ----------
  function setLoading(text, sub) {
    document.getElementById('loading-text').textContent = text || 'Loading…';
    document.getElementById('loading-sub').textContent = sub || '';
    document.getElementById('loading-overlay').classList.remove('hidden');
  }
  function hideLoading() {
    document.getElementById('loading-overlay').classList.add('hidden');
  }
  function setStatus(text, cls) {
    const el = document.getElementById('status-pill');
    el.textContent = text;
    el.className = 'status-pill ' + (cls || '');
  }

  // ---------- MIME ----------
  function getMime(filename) {
    const ext = (filename || '').split('.').pop().toLowerCase();
    const m = {
      html: 'text/html', css: 'text/css', js: 'application/javascript',
      json: 'application/json', svg: 'image/svg+xml',
      png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
      webp: 'image/webp', ico: 'image/x-icon',
      mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg',
      woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf'
    };
    return m[ext] || 'application/octet-stream';
  }

  // ---------- Path utilities ----------
  // Normalize: combine baseFile-dir + href, collapse . and ..
  function normalizePath(baseFile, href) {
    if (!href) return '';
    if (/^(https?:|\/\/|data:|blob:)/i.test(href)) return href;
    const dir = baseFile.includes('/') ? baseFile.substring(0, baseFile.lastIndexOf('/') + 1) : '';
    const combined = dir + href;
    const parts = combined.split('/');
    const stack = [];
    for (const p of parts) {
      if (p === '' || p === '.') continue;
      if (p === '..') stack.pop();
      else stack.push(p);
    }
    return stack.join('/');
  }

  // Smart resolver: try slide-relative first, then root-relative, then literal.
  // This handles both `../shared/foo.css` AND `shared/foo.css` (root-relative) AND `assets/...`.
  async function resolveAsset(baseFile, href) {
    if (!href || /^(https?:|\/\/|data:|blob:)/i.test(href)) return null;

    // 1. Relative to base file (the standard interpretation)
    const relPath = normalizePath(baseFile, href);
    if (await DB.getFile(relPath)) return relPath;

    // 2. As if the project root were the base — strip any leading ../ then try literal
    const stripped = href.replace(/^(\.\.\/)+/, '').replace(/^\.\//, '');
    if (stripped !== relPath && await DB.getFile(stripped)) return stripped;

    // 3. If href starts with the slide folder name, try as project-relative
    if (!stripped.startsWith(SLIDE + '/')) {
      const fromRoot = stripped;
      if (await DB.getFile(fromRoot)) return fromRoot;
    }

    return null; // not found
  }

  // Convert DB path back to relative href from a given source file
  function pathFromBase(baseFile, dbPath) {
    const baseDir = baseFile.includes('/') ? baseFile.substring(0, baseFile.lastIndexOf('/') + 1) : '';
    if (dbPath.startsWith(baseDir)) return dbPath.substring(baseDir.length);
    // Build relative ../-prefixed
    const baseSegs = baseDir.split('/').filter(Boolean);
    const targetSegs = dbPath.split('/');
    let common = 0;
    while (common < baseSegs.length && common < targetSegs.length && baseSegs[common] === targetSegs[common]) common++;
    let up = '';
    for (let i = common; i < baseSegs.length; i++) up += '../';
    return up + targetSegs.slice(common).join('/');
  }

  // ---------- Blob URL helpers ----------
  async function blobUrlForPath(path) {
    const rec = await DB.getFile(path);
    if (!rec) return null;
    const blob = rec.data instanceof Blob ? rec.data : new Blob([rec.data], { type: rec.mime || getMime(path) });
    const url = URL.createObjectURL(blob);
    revokeUrls.push(url);
    blobUrlMap.set(url, path);
    return url;
  }

  // ---------- Rewrite assets within a body to blob URLs (for editor canvas) ----------
  async function replaceAssetsWithBlobUrls(baseFile, root) {
    // src attributes
    for (const el of root.querySelectorAll('img[src], source[src], video[src], audio[src], iframe[src]')) {
      const src = el.getAttribute('src');
      if (!src || /^(https?:|\/\/|data:|blob:)/i.test(src)) continue;
      const resolved = await resolveAsset(baseFile, src);
      if (resolved) {
        const url = await blobUrlForPath(resolved);
        if (url) el.setAttribute('src', url);
      }
    }
    // srcset
    for (const el of root.querySelectorAll('[srcset]')) {
      const ss = el.getAttribute('srcset');
      const parts = ss.split(',').map(p => p.trim());
      const newParts = await Promise.all(parts.map(async (part) => {
        const tokens = part.split(/\s+/);
        const u = tokens[0];
        if (/^(https?:|\/\/|data:|blob:)/i.test(u)) return part;
        const resolved = await resolveAsset(baseFile, u);
        if (!resolved) return part;
        const url = await blobUrlForPath(resolved);
        return [url || u, ...tokens.slice(1)].join(' ');
      }));
      el.setAttribute('srcset', newParts.join(', '));
    }
    // inline style url()
    for (const el of root.querySelectorAll('[style*="url("]')) {
      let style = el.getAttribute('style');
      const matches = [...style.matchAll(/url\(['"]?([^'")]+)['"]?\)/g)];
      for (const m of matches) {
        const u = m[1];
        if (/^(https?:|\/\/|data:|blob:)/i.test(u)) continue;
        const resolved = await resolveAsset(baseFile, u);
        if (!resolved) continue;
        const url = await blobUrlForPath(resolved);
        if (url) style = style.split(m[0]).join(`url("${url}")`);
      }
      el.setAttribute('style', style);
    }
  }

  // Rewrite url() refs in CSS text — used for stylesheets loaded into the editor canvas.
  // basePath is the CSS file's own path (so its url(...) refs resolve relative to it).
  async function rewriteCssUrls(cssText, basePath) {
    const matches = [...cssText.matchAll(/url\(['"]?([^'")]+)['"]?\)/g)];
    let result = cssText;
    for (const m of matches) {
      const u = m[1];
      if (/^(https?:|\/\/|data:|blob:)/i.test(u) || u.startsWith('#')) continue;
      const resolved = await resolveAsset(basePath, u);
      if (!resolved) continue;
      const url = await blobUrlForPath(resolved);
      if (url) result = result.split(m[0]).join(`url("${url}")`);
    }
    return result;
  }

  // ---------- Collect images for asset manager ----------
  async function collectSlideImages() {
    const all = await DB.listFiles();
    const result = [];
    for (const f of all) {
      const isImage = /^image\//.test(f.mime || '') || /\.(png|jpe?g|gif|webp|svg|bmp|ico)$/i.test(f.path);
      if (!isImage) continue;
      const inSlide = f.path.startsWith(SLIDE + '/');
      const inShared = f.path.startsWith('shared/');
      if (!inSlide && !inShared) continue;
      const url = await blobUrlForPath(f.path);
      if (url) result.push({ src: url, name: f.path.split('/').pop(), type: 'image' });
    }
    return result;
  }

  // ---------- Load slide ----------
  async function loadSlide() {
    setLoading('Loading slide…', INDEX_PATH);
    const idx = await DB.getFile(INDEX_PATH);
    if (!idx) throw new Error('index.html not found for ' + SLIDE);

    const htmlText = await DB.blobToText(idx.data);
    originalHtmlText = htmlText;                              // ← authoritative source for save
    originalDoc = new DOMParser().parseFromString(htmlText, 'text/html');

    // Diagnostic — verify DB returned the full file
    const rawScriptCount = (htmlText.match(/<script\b/gi) || []).length;
    const rawLinkCount = (htmlText.match(/<link\b/gi) || []).length;
    console.log('[IVA] Loaded', INDEX_PATH, '— DB content size:', idx.data.size, 'bytes, raw scripts:', rawScriptCount, ', raw links:', rawLinkCount);
    if (rawScriptCount === 0) {
      console.warn('[IVA] The stored index.html has ZERO <script> tags. If your original had scripts, the upload may have stored a different file or the source file was already empty of scripts.');
    }

    // Diagnostic: report every <link>/<script>/<img>/<style> ref we encounter
    const diagnostics = { resolved: [], missing: [] };

    // 1. Collect external stylesheets — load each, rewrite its url() refs to blob URLs,
    //    create a blob URL for the CSS file and pass to GrapeJS canvas.styles.
    const canvasStyles = [];
    for (const link of [...originalDoc.querySelectorAll('link[rel="stylesheet"][href]')]) {
      const href = link.getAttribute('href');
      if (/^(https?:|\/\/|data:)/i.test(href)) {
        canvasStyles.push(href);
        continue;
      }
      const resolved = await resolveAsset(INDEX_PATH, href);
      if (!resolved) {
        diagnostics.missing.push({ kind: 'css', href });
        console.warn('[IVA] Stylesheet not found in storage:', href, '(referenced from', INDEX_PATH, ')');
        continue;
      }
      diagnostics.resolved.push({ kind: 'css', href, resolved });
      const rec = await DB.getFile(resolved);
      if (!rec) continue;
      const cssText = await DB.blobToText(rec.data);
      const rewritten = await rewriteCssUrls(cssText, resolved);
      const blobUrl = URL.createObjectURL(new Blob([rewritten], { type: 'text/css' }));
      revokeUrls.push(blobUrl);
      blobUrlMap.set(blobUrl, resolved);
      canvasStyles.push(blobUrl);
    }

    // 2. Inline <style> tags (with url() rewritten)
    let inlineStyles = '';
    for (const s of originalDoc.querySelectorAll('style')) {
      if (!s.textContent) continue;
      inlineStyles += (await rewriteCssUrls(s.textContent, INDEX_PATH)) + '\n';
    }

    // 3. Collect ALL <script> tags (head + body) — we'll re-inject them into the canvas
    //    after the body is rendered, so popup/interactive scripts can run during editing.
    //    Scripts in the body would otherwise be stripped by GrapeJS (allowScripts: false default).
    const canvasScripts = [];
    for (const sc of [...originalDoc.querySelectorAll('script')]) {
      const src = sc.getAttribute('src');
      const type = sc.getAttribute('type') || '';
      // Skip non-JS scripts (e.g., JSON-LD) — they're preserved in originalHtmlText, but
      // don't need to run in canvas
      if (type && type !== 'text/javascript' && type !== 'application/javascript' && type !== 'module') {
        continue;
      }
      if (src) {
        if (/^(https?:|\/\/|data:|blob:)/i.test(src)) {
          canvasScripts.push({ src: src, code: null });
          continue;
        }
        const resolved = await resolveAsset(INDEX_PATH, src);
        if (!resolved) {
          diagnostics.missing.push({ kind: 'js', href: src });
          console.warn('[IVA] Script not found in storage:', src);
          continue;
        }
        const rec = await DB.getFile(resolved);
        if (!rec) continue;
        const code = await DB.blobToText(rec.data);
        diagnostics.resolved.push({ kind: 'js', href: src, resolved });
        canvasScripts.push({ src: null, code: code, sourcePath: resolved });
      } else if (sc.textContent && sc.textContent.trim()) {
        canvasScripts.push({ src: null, code: sc.textContent });
      }
    }

    // 4. Body — rewrite asset refs to blob URLs, strip scripts (we restore them on save & inject into canvas separately)
    const body = originalDoc.body.cloneNode(true);
    [...body.querySelectorAll('script')].forEach(s => s.remove());
    [...body.querySelectorAll('link[rel="stylesheet"]')].forEach(l => l.remove());
    await replaceAssetsWithBlobUrls(INDEX_PATH, body);

    // 5. Pre-populate asset manager
    const existingImages = await collectSlideImages();

    hideLoading();

    // Log a summary so issues are visible in console
    if (diagnostics.missing.length) {
      console.warn('[IVA] ' + diagnostics.missing.length + ' assets could not be resolved:', diagnostics.missing);
      toast({
        type: 'info',
        title: 'Some assets missing',
        message: diagnostics.missing.length + ' file(s) referenced by this slide are not in storage. Check console for details.',
        duration: 5000
      });
    }
    console.log('[IVA] Loaded slide. Stylesheets:', diagnostics.resolved.filter(d => d.kind === 'css').length,
                'Scripts:', canvasScripts.length, 'Missing:', diagnostics.missing.length);

    return {
      bodyHtml: body.innerHTML,
      inlineStyles,
      canvasStyles,
      canvasScripts,
      existingImages
    };
  }

  // ---------- Save ----------
  // Replace blob: URLs in saved HTML/CSS with proper relative paths
  function replaceBlobUrlsWithPaths(text, fromFile) {
    const re = /blob:[^"'\s)]+/g;
    const matches = [...new Set(text.match(re) || [])];
    for (const url of matches) {
      const dbPath = blobUrlMap.get(url);
      if (dbPath) {
        const rel = pathFromBase(fromFile, dbPath);
        text = text.split(url).join(rel);
      }
    }
    return text;
  }

  async function saveSlide(silent) {
    if (!editor || !originalHtmlText) return;
    setStatus('Saving…');
    try {
      let bodyHtml = editor.getHtml();
      let css = editor.getCss();

      bodyHtml = replaceBlobUrlsWithPaths(bodyHtml, INDEX_PATH);
      css = replaceBlobUrlsWithPaths(css, INDEX_PATH);

      // ============================================================
      // STRING-BASED SAVE — DOMParser-free.
      // We never re-serialize the original HTML through DOMParser
      // because that can sometimes drop or rearrange scripts/links.
      // Instead, we locate the body and head positions in the
      // original string and surgically replace ONLY the editable
      // region inside <body>, leaving every <script>, <link>,
      // <meta>, <title>, and head content byte-identical.
      // ============================================================

      // 1. Find <body...> opening tag and </body> closing tag in originalHtmlText
      const bodyOpenMatch = originalHtmlText.match(/<body\b[^>]*>/i);
      const bodyCloseIdx = originalHtmlText.search(/<\/body\s*>/i);
      if (!bodyOpenMatch || bodyCloseIdx === -1) {
        throw new Error('Could not locate <body>...</body> in original HTML');
      }
      const bodyOpenEnd = bodyOpenMatch.index + bodyOpenMatch[0].length;
      const originalBodyInner = originalHtmlText.substring(bodyOpenEnd, bodyCloseIdx);

      // 2. Extract every <script>...</script> block and every <link rel="stylesheet"...> tag
      //    from the original body so we can re-attach them after the new edited body content.
      const preservedScripts = [];
      const scriptRegex = /<script\b[\s\S]*?<\/script\s*>/gi;
      let m;
      while ((m = scriptRegex.exec(originalBodyInner)) !== null) {
        preservedScripts.push(m[0]);
      }
      const preservedLinks = [];
      const linkRegex = /<link\b[^>]*\brel\s*=\s*["']?stylesheet["']?[^>]*\/?>/gi;
      while ((m = linkRegex.exec(originalBodyInner)) !== null) {
        preservedLinks.push(m[0]);
      }

      // 3. Build new body inner content:  edited HTML  +  preserved links  +  preserved scripts
      const newBodyInner =
        '\n' + bodyHtml + '\n' +
        (preservedLinks.length ? preservedLinks.join('\n') + '\n' : '') +
        (preservedScripts.length ? preservedScripts.join('\n') + '\n' : '');

      // 4. Update or insert <style data-editor-styles> in the head portion (still string-based)
      const headPortion = originalHtmlText.substring(0, bodyOpenMatch.index);
      const remainingPortion = originalHtmlText.substring(bodyCloseIdx); // includes </body>...</html>
      const bodyOpenTag = bodyOpenMatch[0];

      const editorStyleTag = '<style data-editor-styles>\n' + css + '\n</style>';
      const editorStyleRegex = /<style\b[^>]*\bdata-editor-styles\b[^>]*>[\s\S]*?<\/style\s*>/i;
      let newHeadPortion;
      if (editorStyleRegex.test(headPortion)) {
        newHeadPortion = headPortion.replace(editorStyleRegex, editorStyleTag);
      } else {
        // Insert before </head> if found, otherwise just before <body>
        const headCloseMatch = headPortion.match(/<\/head\s*>/i);
        if (headCloseMatch) {
          newHeadPortion =
            headPortion.substring(0, headCloseMatch.index) +
            editorStyleTag + '\n' +
            headPortion.substring(headCloseMatch.index);
        } else {
          newHeadPortion = headPortion + editorStyleTag + '\n';
        }
      }

      // 5. Assemble final HTML
      const finalHtml = newHeadPortion + bodyOpenTag + newBodyInner + remainingPortion;

      // 6. Diagnostic — counts before/after
      const origScripts = (originalHtmlText.match(/<script\b/gi) || []).length;
      const origLinks = (originalHtmlText.match(/<link\b/gi) || []).length;
      const newScripts = (finalHtml.match(/<script\b/gi) || []).length;
      const newLinks = (finalHtml.match(/<link\b/gi) || []).length;

      console.log(
        '[IVA] Save string-based — scripts:', origScripts, '→', newScripts,
        '| links:', origLinks, '→', newLinks,
        '| body scripts preserved:', preservedScripts.length,
        '| body links preserved:', preservedLinks.length
      );

      if (newScripts < origScripts || newLinks < origLinks) {
        console.error('[IVA] WARNING: tag count dropped during save. Saving original HTML untouched as fallback.');
        // Hard fallback — never lose tags. Save the original with only the style tag updated.
        const safeHtml = newHeadPortion + bodyOpenTag + originalBodyInner + remainingPortion;
        const blob = new Blob([safeHtml], { type: 'text/html' });
        await DB.putFile(INDEX_PATH, blob, 'text/html');
        originalHtmlText = safeHtml;
        modified = false;
        setStatus('Saved (safe mode)', 'saved');
        toast({
          type: 'warning',
          title: 'Saved in safe mode',
          message: 'Body edits skipped to preserve original scripts/links. Check console.',
          duration: 6000
        });
        return;
      }

      const blob = new Blob([finalHtml], { type: 'text/html' });
      await DB.putFile(INDEX_PATH, blob, 'text/html');

      // Update authoritative source for next save
      originalHtmlText = finalHtml;
      // Refresh originalDoc too (for the canvas-script injection path)
      originalDoc = new DOMParser().parseFromString(finalHtml, 'text/html');

      modified = false;
      setStatus('Saved', 'saved');
      document.getElementById('last-saved').textContent = new Date().toLocaleTimeString();

      if (!silent) {
        toast({
          type: 'success',
          title: 'Saved to browser storage',
          message: `Updated ${INDEX_PATH} (${newLinks} link tag${newLinks === 1 ? '' : 's'}, ${newScripts} script tag${newScripts === 1 ? '' : 's'} preserved).`,
          duration: 5000
        });
      }
    } catch (err) {
      console.error(err);
      setStatus('Save failed', 'error');
      toast({ type: 'error', title: 'Save failed', message: err.message });
    }
  }

  // ---------- Preview (new tab, fully self-contained) ----------
  async function previewSlide() {
    if (!editor || !originalHtmlText) return;
    try {
      if (modified) await saveSlide(true);
      const html = await window.IVAPreview.buildSelfContainedHtml(INDEX_PATH);
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const win = window.open(url, '_blank');
      if (!win) toast({ type: 'error', title: 'Popup blocked', message: 'Allow popups to preview' });
      setTimeout(() => URL.revokeObjectURL(url), 60000);
    } catch (err) {
      console.error(err);
      toast({ type: 'error', title: 'Preview failed', message: err.message });
    }
  }

  // ---------- Image upload ----------
  async function handleImageUpload(e) {
    const files = (e && e.dataTransfer && e.dataTransfer.files) || (e && e.target && e.target.files) || [];
    if (!files || !files.length) return;
    const am = editor.AssetManager;
    for (const file of files) {
      try {
        if (!file.type.startsWith('image/')) continue;
        let name = file.name.replace(/[^\w.\-]/g, '_');
        let dbPath = SLIDE + '/assets/images/' + name;
        const exists = await DB.getFile(dbPath);
        if (exists) dbPath = SLIDE + '/assets/images/' + Date.now() + '_' + name;
        await DB.putFile(dbPath, file, file.type);
        const url = await blobUrlForPath(dbPath);
        am.add({ src: url, type: 'image', name: dbPath.split('/').pop() });
      } catch (err) {
        console.error(err);
        toast({ type: 'error', title: 'Upload failed', message: err.message });
      }
    }
    toast({ type: 'success', title: 'Image uploaded' });
  }

  // ---------- Custom blocks ----------
  function getCustomBlocks() {
    return [
      { id: 'section', label: 'Section', category: 'Basic',
        content: '<section style="padding:40px 24px;"><h2>Section Title</h2><p>Add your content here.</p></section>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/></svg>' },
      { id: 'heading', label: 'Heading', category: 'Basic',
        content: '<h2 style="font-size:32px;font-weight:600;">Heading</h2>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 4v16M18 4v16M6 12h12"/></svg>' },
      { id: 'text', label: 'Text', category: 'Basic',
        content: '<p style="font-size:16px;line-height:1.6;">Insert your text here. Click to edit.</p>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 6h16M4 12h16M4 18h10"/></svg>' },
      { id: 'image', label: 'Image', category: 'Basic',
        content: { type: 'image', style: { color: 'black' } }, activate: true,
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-5-5L5 21"/></svg>' },
      { id: 'button', label: 'Button', category: 'Basic',
        content: '<a href="#" style="display:inline-block;padding:12px 24px;background:#0c0d10;color:#fff;text-decoration:none;border-radius:6px;font-weight:500;">Button</a>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="8" width="18" height="8" rx="4"/></svg>' },
      { id: 'link', label: 'Link', category: 'Basic',
        content: '<a href="#" style="color:#2563eb;text-decoration:underline;">Link text</a>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07L11 5"/><path d="M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07L13 19"/></svg>' },
      { id: 'divider', label: 'Divider', category: 'Basic',
        content: '<hr style="border:none;border-top:1px solid #e5e7eb;margin:24px 0;"/>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="4" y1="12" x2="20" y2="12"/></svg>' },
      { id: 'spacer', label: 'Spacer', category: 'Basic',
        content: '<div style="height:40px;"></div>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 9l7-4 7 4M5 15l7 4 7-4"/></svg>' },
      { id: 'list', label: 'List', category: 'Basic',
        content: '<ul style="padding-left:24px;line-height:1.7;"><li>First item</li><li>Second item</li><li>Third item</li></ul>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/></svg>' },
      { id: 'columns-2', label: '2 Columns', category: 'Layout',
        content: '<div style="display:flex;gap:20px;padding:20px 0;"><div style="flex:1;padding:20px;background:#f5f5f5;">Column 1</div><div style="flex:1;padding:20px;background:#f5f5f5;">Column 2</div></div>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="8" height="16"/><rect x="13" y="4" width="8" height="16"/></svg>' },
      { id: 'columns-3', label: '3 Columns', category: 'Layout',
        content: '<div style="display:flex;gap:16px;padding:20px 0;"><div style="flex:1;padding:16px;background:#f5f5f5;">Column 1</div><div style="flex:1;padding:16px;background:#f5f5f5;">Column 2</div><div style="flex:1;padding:16px;background:#f5f5f5;">Column 3</div></div>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="5" height="16"/><rect x="9.5" y="4" width="5" height="16"/><rect x="16" y="4" width="5" height="16"/></svg>' },
      { id: 'card', label: 'Card', category: 'Layout',
        content: '<div style="border:1px solid #e5e7eb;border-radius:8px;padding:20px;background:#fff;"><h3 style="margin:0 0 8px 0;">Card title</h3><p style="margin:0;color:#6b7280;">Card body text.</p></div>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/></svg>' },
      { id: 'video', label: 'Video', category: 'Media',
        content: '<video controls style="max-width:100%;"><source src="" type="video/mp4"></video>',
        media: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/></svg>' }
    ];
  }

  // ---------- Init GrapeJS ----------
  async function initEditor() {
    let slideData;
    try { slideData = await loadSlide(); }
    catch (err) {
      console.error(err);
      alert('Could not load slide: ' + err.message);
      location.href = 'index.html';
      return;
    }

    const deviceSelect = document.getElementById('device-select');
    IPAD_DEVICES.forEach(d => {
      const opt = document.createElement('option');
      opt.value = d.id;
      opt.textContent = d.name;
      deviceSelect.appendChild(opt);
    });

    editor = grapesjs.init({
      container: '#gjs',
      height: '100%',
      width: 'auto',
      fromElement: false,
      storageManager: false,
      panels: { defaults: [] },
      showOffsets: true,
      avoidInlineStyle: false,
      noticeOnUnload: false,
      canvas: {
        styles: slideData.canvasStyles,
        scripts: [],
        frameContent: slideData.inlineStyles ? `<style>${slideData.inlineStyles}</style>` : ''
      },
      deviceManager: {
        devices: IPAD_DEVICES.map(d => ({ id: d.id, name: d.name, width: d.w + 'px', height: d.h + 'px' }))
      },
      blockManager: { appendTo: '#blocks-container', blocks: getCustomBlocks() },
      layerManager: {
  appendTo: '#layers-container',
  root: 'wrapper',
  showWrapper: true,
  showHover: true,
  scrollLayers: true,
  highlightHover: true,
  highlightSelected: true
},
      styleManager: {
        appendTo: '#styles-container',
        sectors: [
          { name: 'Layout',     open: false, buildProps: ['display', 'position', 'top', 'right', 'left', 'bottom', 'z-index'] },
          { name: 'Dimension',  open: false, buildProps: ['width', 'height', 'max-width', 'min-height', 'margin', 'padding'] },
          {
            name: 'Typography', open: true,
            buildProps: ['font-family', 'font-size', 'font-weight', 'letter-spacing', 'color', 'line-height', 'text-align', 'text-shadow'],
            properties: [
              { property: 'color', type: 'color', defaults: 'none' }
            ]
          },
          {
            name: 'Background', open: false,
            buildProps: ['background-color', 'background-image', 'background-repeat', 'background-position', 'background-size'],
            properties: [
              { property: 'background-color', type: 'color', defaults: 'none' }
            ]
          },
          { name: 'Border',     open: false, buildProps: ['border', 'border-radius', 'box-shadow'] },
          { name: 'Effects',    open: false, buildProps: ['opacity', 'transform', 'transition', 'cursor'] }
        ]
      },
      traitManager: { appendTo: '#traits-container' },
      selectorManager: { appendTo: '#selectors-container' },
      assetManager: {
        assets: slideData.existingImages,
        upload: false,
        uploadFile: handleImageUpload,
        multiUpload: true,
        autoAdd: true
      }
    });

    editor.setComponents(slideData.bodyHtml);
    // Force layer panel to expand all nodes by default and select child on click
editor.on('component:selected', (comp) => {
  // Walk up the tree and open each parent so the selected node is visible
  let parent = comp.parent();
  while (parent) {
    parent.set('open', true);
    parent = parent.parent();
  }
});
// Expand top-level layers on initial load
setTimeout(() => {
  const wrapper = editor.getWrapper();
  if (wrapper) {
    wrapper.set('open', true);
    wrapper.components().each(c => c.set('open', true));
  }
}, 300);
    editor.setDevice('ipad-portrait');
    deviceSelect.value = 'ipad-portrait';

    wireUi();
    initCodeEditors();
    setStatus('Ready', 'saved');

    // Inject scripts into the canvas iframe so popups / interactive widgets
    // work in editor view. They're appended at the END of the canvas body,
    // AFTER the editable content, so DOM queries succeed.
    function injectCanvasScripts() {
      try {
        const cdoc = editor.Canvas.getDocument();
        if (!cdoc || !cdoc.body) return false;
        // Remove previously-injected scripts (in case of re-injection on device change)
        [...cdoc.querySelectorAll('script[data-iva-injected]')].forEach(s => s.remove());
        for (const script of slideData.canvasScripts) {
          const s = cdoc.createElement('script');
          s.setAttribute('data-iva-injected', '');
          if (script.src) {
            s.src = script.src;
          } else if (script.code) {
            s.textContent = script.code;
          }
          // Append at end of body so scripts run after content exists
          cdoc.body.appendChild(s);
        }
        return true;
      } catch (e) {
        console.warn('[IVA] Failed to inject canvas scripts:', e);
        return false;
      }
    }

    // Try immediately, retry once after a short delay (in case canvas isn't ready)
    if (slideData.canvasScripts && slideData.canvasScripts.length) {
      setTimeout(() => {
        if (!injectCanvasScripts()) {
          setTimeout(injectCanvasScripts, 400);
        }
      }, 100);

      // Re-inject when device changes (device change recreates the iframe)
      editor.on('change:device', () => {
        setTimeout(injectCanvasScripts, 200);
      });
    }

    editor.on('component:add component:remove component:update style:update', () => {
      if (!modified) {
        modified = true;
        setStatus('Unsaved changes', 'modified');
      }
    });

    // When a component is selected, populate the per-component HTML/CSS code panel
    editor.on('component:selected component:deselected', updateSelectedComponentCode);
    editor.on('component:update style:update', updateSelectedComponentCode);
  }

  // ---------- Per-component HTML/CSS panel ----------
  function initCodeEditors() {
    if (!window.CodeMirror) return;

    // Per-component HTML
    selectorCmHtml = CodeMirror(document.getElementById('selected-html-host'), {
      mode: 'htmlmixed',
      theme: 'darcula-iva',
      lineNumbers: true,
      lineWrapping: true,
      indentUnit: 2,
      tabSize: 2,
      readOnly: false
    });
    selectorCmCss = CodeMirror(document.getElementById('selected-css-host'), {
      mode: 'css',
      theme: 'darcula-iva',
      lineNumbers: true,
      lineWrapping: true,
      indentUnit: 2,
      tabSize: 2,
      readOnly: false
    });
    selectorCmHtml.setSize('100%', '100%');
    selectorCmCss.setSize('100%', '100%');

    // Apply button — re-parse & replace selected component
    document.getElementById('apply-component-html').addEventListener('click', applyComponentHtml);
    document.getElementById('apply-component-css').addEventListener('click', applyComponentCss);
  }

  function updateSelectedComponentCode() {
    if (!selectorCmHtml) return;
    const sel = editor.getSelected();
    if (!sel) {
      selectorCmHtml.setValue('// Select a component to edit its HTML');
      selectorCmCss.setValue('/* Select a component to edit its CSS */');
      document.getElementById('apply-component-html').disabled = true;
      document.getElementById('apply-component-css').disabled = true;
      return;
    }
    try {
      const html = sel.toHTML();
      let css = '';
      try { css = editor.CodeManager.getCode(sel, 'css', { cssc: editor.CssComposer }) || ''; }
      catch (e) { /* fallback */ }
      // Replace blob URLs for readability
      selectorCmHtml.setValue(replaceBlobUrlsWithPaths(html, INDEX_PATH));
      selectorCmCss.setValue(replaceBlobUrlsWithPaths(css, INDEX_PATH));
      document.getElementById('apply-component-html').disabled = false;
      document.getElementById('apply-component-css').disabled = false;
    } catch (err) {
      console.warn(err);
    }
  }

  function applyComponentHtml() {
    const sel = editor.getSelected();
    if (!sel) return;
    try {
      const html = selectorCmHtml.getValue();
      sel.replaceWith(html);
      modified = true;
      setStatus('Unsaved changes', 'modified');
      toast({ type: 'success', title: 'Component updated' });
    } catch (err) {
      toast({ type: 'error', title: 'Invalid HTML', message: err.message });
    }
  }

  function applyComponentCss() {
    const sel = editor.getSelected();
    if (!sel) return;
    try {
      const css = selectorCmCss.getValue();
      // Add as a custom CSS rule scoped to a class on the selected component
      let cls = sel.getClasses().map(c => typeof c === 'string' ? c : c.get('name'))[0];
      if (!cls) {
        cls = 'gjs-comp-' + Math.random().toString(36).slice(2, 9);
        sel.addClass(cls);
      }
      // Replace any existing rules for selected via the CssComposer
      editor.CssComposer.addRules(css);
      modified = true;
      setStatus('Unsaved changes', 'modified');
      toast({ type: 'success', title: 'CSS applied' });
    } catch (err) {
      toast({ type: 'error', title: 'Invalid CSS', message: err.message });
    }
  }

  // ---------- Full-page code modal ----------
  // Builds the FULL slide HTML (head + body + every script + every link)
  // so the modal shows everything that will be saved to disk — including
  // the original <script> tags and shared/ <link> tags that GrapeJS doesn't expose.
  function buildFullSlideHtml() {
    const doc = new DOMParser().parseFromString(originalHtmlText, 'text/html');

    // Replace the editable body with current canvas content, preserving scripts/links at end
    let bodyHtml = editor.getHtml();
    bodyHtml = replaceBlobUrlsWithPaths(bodyHtml, INDEX_PATH);

    const preservedBodyTags = [];
    for (const sc of [...doc.body.querySelectorAll('script')]) {
      preservedBodyTags.push(sc.outerHTML);
    }
    for (const el of [...doc.body.children]) {
      if (el.tagName === 'LINK' && (el.getAttribute('rel') || '').toLowerCase() === 'stylesheet') {
        preservedBodyTags.push(el.outerHTML);
      }
    }

    doc.body.innerHTML = bodyHtml;
    for (const html of preservedBodyTags) {
      doc.body.insertAdjacentHTML('beforeend', html);
    }

    // Update editor's CSS block so the modal shows it inline
    let css = editor.getCss();
    css = replaceBlobUrlsWithPaths(css, INDEX_PATH);
    let styleEl = doc.querySelector('style[data-editor-styles]');
    if (!styleEl) {
      styleEl = doc.createElement('style');
      styleEl.setAttribute('data-editor-styles', '');
      doc.head.appendChild(styleEl);
    }
    styleEl.textContent = css;

    return '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
  }

  function openCodeModal(mode) {
    codeModalMode = mode || 'html';
    document.getElementById('code-modal').classList.add('active');
    document.getElementById('code-modal-title').textContent = codeModalMode === 'css' ? 'Edit CSS' : 'Edit HTML (full document)';
    document.querySelectorAll('.code-tab').forEach(t => t.classList.toggle('active', t.dataset.codeMode === codeModalMode));

    if (!codeModalEditor) {
      codeModalEditor = CodeMirror(document.getElementById('code-modal-host'), {
        mode: codeModalMode === 'css' ? 'css' : 'htmlmixed',
        theme: 'darcula-iva',
        lineNumbers: true,
        lineWrapping: false,
        indentUnit: 2,
        tabSize: 2,
        styleActiveLine: true
      });
      codeModalEditor.setOption('extraKeys', {
        'Ctrl-F': 'findPersistent',
        'Cmd-F': 'findPersistent',
        'Ctrl-G': 'findNext',
        'Cmd-G': 'findNext',
        'Ctrl-H': 'replace',
        'Cmd-Alt-F': 'replace'
      });
    }
    codeModalEditor.setOption('mode', codeModalMode === 'css' ? 'css' : 'htmlmixed');

    if (codeModalMode === 'css') {
      let css = editor.getCss();
      css = replaceBlobUrlsWithPaths(css, INDEX_PATH);
      codeModalEditor.setValue(css);
    } else {
      // FULL HTML — head + body + scripts + links, all preserved
      const html = buildFullSlideHtml();
      codeModalEditor.setValue(html);
    }
    setTimeout(() => codeModalEditor.refresh(), 50);
  }

  function closeCodeModal() {
    document.getElementById('code-modal').classList.remove('active');
  }

  async function applyCodeModal() {
    if (!codeModalEditor) return;
    const value = codeModalEditor.getValue();
    try {
      if (codeModalMode === 'css') {
        editor.setStyle(value);
        modified = true;
        setStatus('Unsaved changes', 'modified');
        toast({ type: 'success', title: 'Applied', message: 'CSS updated in canvas' });
      } else {
        // Full-document edit: parse the user's HTML, update originalHtmlText
        // (so any changes to head/scripts/links persist), then load body into canvas.
        const doc = new DOMParser().parseFromString(value, 'text/html');
        if (!doc.body) throw new Error('Invalid HTML — no <body> tag found');

        // Update authoritative source — this is what saveSlide reads from
        originalHtmlText = '<!DOCTYPE html>\n' + doc.documentElement.outerHTML;
        originalDoc = doc;

        // Strip scripts/links from body before sending to GrapeJS (it would strip them anyway,
        // but we want them preserved in originalHtmlText for save).
        const bodyClone = doc.body.cloneNode(true);
        [...bodyClone.querySelectorAll('script')].forEach(s => s.remove());
        [...bodyClone.querySelectorAll('link[rel="stylesheet"]')].forEach(l => l.remove());

        editor.setComponents(bodyClone.innerHTML);
        modified = true;
        setStatus('Unsaved changes', 'modified');

        const scriptCount = (value.match(/<script\b/gi) || []).length;
        const linkCount = (value.match(/<link[^>]*rel=["']?stylesheet/gi) || []).length;
        toast({
          type: 'success',
          title: 'HTML applied',
          message: `Head, body, ${linkCount} stylesheet${linkCount === 1 ? '' : 's'}, and ${scriptCount} script${scriptCount === 1 ? '' : 's'} preserved.`,
          duration: 4000
        });
      }
      closeCodeModal();
    } catch (err) {
      toast({ type: 'error', title: 'Apply failed', message: err.message });
    }
  }

  // Custom Find UI for code modal (search bar)
  function runCodeSearch(query) {
    if (!codeModalEditor || !query) return;
    const SearchCursor = codeModalEditor.getSearchCursor(query, codeModalEditor.getCursor(), { caseFold: true });
    if (SearchCursor.findNext()) {
      codeModalEditor.setSelection(SearchCursor.from(), SearchCursor.to());
      codeModalEditor.scrollIntoView({ from: SearchCursor.from(), to: SearchCursor.to() }, 80);
    } else {
      // Wrap around
      const cur2 = codeModalEditor.getSearchCursor(query, { line: 0, ch: 0 }, { caseFold: true });
      if (cur2.findNext()) {
        codeModalEditor.setSelection(cur2.from(), cur2.to());
        codeModalEditor.scrollIntoView({ from: cur2.from(), to: cur2.to() }, 80);
      } else {
        toast({ type: 'info', title: 'No matches', message: query });
      }
    }
  }

  // ---------- Wire UI ----------
  function wireUi() {
    // Device select & rotate
    document.getElementById('device-select').addEventListener('change', (e) => {
      editor.setDevice(e.target.value);
      updateCanvasDims();
    });
    document.getElementById('rotate-btn').addEventListener('click', () => {
      const sel = document.getElementById('device-select');
      const cur = sel.value;
      const isPortrait = cur.includes('portrait');
      const target = isPortrait ? cur.replace('portrait', 'landscape') : cur.replace('landscape', 'portrait');
      if (IPAD_DEVICES.find(d => d.id === target)) {
        sel.value = target;
        editor.setDevice(target);
        updateCanvasDims();
      }
    });

    // Undo/Redo
    document.getElementById('undo-btn').addEventListener('click', () => editor.UndoManager.undo());
    document.getElementById('redo-btn').addEventListener('click', () => editor.UndoManager.redo());

    // Outline toggle
    document.getElementById('outline-btn').addEventListener('click', (e) => {
      const cmd = editor.Commands;
      if (cmd.isActive('sw-visibility')) {
        cmd.stop('sw-visibility');
        e.currentTarget.classList.remove('active');
      } else {
        cmd.run('sw-visibility');
        e.currentTarget.classList.add('active');
      }
    });

    // Fullscreen
    document.getElementById('fullscreen-btn').addEventListener('click', () => {
      if (!document.fullscreenElement) document.documentElement.requestFullscreen();
      else document.exitFullscreen();
    });

    // Preview / Save / Back
    document.getElementById('preview-btn').addEventListener('click', previewSlide);
    document.getElementById('save-btn').addEventListener('click', () => saveSlide(false));
    document.getElementById('back-btn').addEventListener('click', () => {
      if (modified && !confirm('You have unsaved changes. Leave anyway?')) return;
      location.href = 'index.html';
    });

    // Code editor top buttons
    document.getElementById('edit-html-btn').addEventListener('click', () => openCodeModal('html'));
    document.getElementById('edit-css-btn').addEventListener('click', () => openCodeModal('css'));

    // Code modal controls
    document.getElementById('code-modal-close').addEventListener('click', closeCodeModal);
    document.getElementById('code-modal-apply').addEventListener('click', applyCodeModal);
    document.querySelectorAll('.code-tab').forEach(tab => {
      tab.addEventListener('click', () => openCodeModal(tab.dataset.codeMode));
    });
    document.getElementById('code-modal-search').addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); runCodeSearch(e.target.value); }
    });
    document.getElementById('code-search-btn').addEventListener('click', () => {
      runCodeSearch(document.getElementById('code-modal-search').value);
    });

    // Zoom
    document.getElementById('zoom-in-btn').addEventListener('click', () => setZoom(currentZoom + 10));
    document.getElementById('zoom-out-btn').addEventListener('click', () => setZoom(currentZoom - 10));
    document.getElementById('zoom-reset-btn').addEventListener('click', () => setZoom(100));
    document.getElementById('zoom-fit-btn').addEventListener('click', () => {
      const wrap = document.querySelector('.canvas-wrap');
      const dev = IPAD_DEVICES.find(d => d.id === document.getElementById('device-select').value);
      if (!dev || !wrap) return;
      const ratio = Math.min((wrap.clientWidth - 80) / dev.w, (wrap.clientHeight - 80) / dev.h);
      setZoom(Math.floor(ratio * 100));
    });

    // Tabs (left + right)
    document.querySelectorAll('.panel-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        const parent = tab.closest('.side-panel');
        parent.querySelectorAll('.panel-tab').forEach(t => t.classList.remove('active'));
        parent.querySelectorAll('.panel-section').forEach(s => s.classList.remove('active'));
        tab.classList.add('active');
        parent.querySelector('#' + tab.dataset.target).classList.add('active');
        // Refresh CodeMirror in case it was hidden
        if (selectorCmHtml && tab.dataset.target === 'code-section') {
          setTimeout(() => { selectorCmHtml.refresh(); selectorCmCss.refresh(); }, 50);
        }
      });
    });

    // Keyboard
    document.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveSlide(false); }
      else if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) { e.preventDefault(); editor.UndoManager.undo(); }
      else if ((e.ctrlKey || e.metaKey) && (e.key === 'y' || (e.shiftKey && e.key.toLowerCase() === 'z'))) {
        e.preventDefault(); editor.UndoManager.redo();
      }
    });

    function updateUndoRedo() {
      const um = editor.UndoManager;
      document.getElementById('undo-btn').disabled = !um.hasUndo();
      document.getElementById('redo-btn').disabled = !um.hasRedo();
    }
    editor.on('component:add component:remove component:update style:update update', updateUndoRedo);
    editor.on('undo redo', updateUndoRedo);
    updateUndoRedo();
    updateCanvasDims();

    window.addEventListener('beforeunload', (e) => {
      if (modified) { e.preventDefault(); e.returnValue = ''; }
    });
  }

  function setZoom(z) {
    currentZoom = Math.max(20, Math.min(200, Math.round(z)));
    try { editor.Canvas.setZoom(currentZoom); } catch (e) {}
    document.getElementById('zoom-label').textContent = currentZoom + '%';
  }
  function updateCanvasDims() {
    const id = document.getElementById('device-select').value;
    const d = IPAD_DEVICES.find(x => x.id === id);
    if (d) document.getElementById('canvas-dims').textContent = `${d.w} × ${d.h}`;
  }

  // ---------- Cleanup ----------
  window.addEventListener('beforeunload', () => {
    revokeUrls.forEach(url => { try { URL.revokeObjectURL(url); } catch (e) {} });
  });

  // ---------- Boot ----------
  initEditor();
})();
