/* ============================================================
   IndexedDB Storage Layer
   - Stores project files keyed by their relative path
   - Stores meta keyed by string keys
   ============================================================ */
(function (global) {
  'use strict';

  const DB_NAME = 'IVAEditor';
  const DB_VERSION = 1;
  const STORE_FILES = 'files';
  const STORE_META = 'meta';

  let _db = null;

  function open() {
    if (_db) return Promise.resolve(_db);
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = (e) => {
        const db = e.target.result;
        if (!db.objectStoreNames.contains(STORE_FILES)) {
          db.createObjectStore(STORE_FILES, { keyPath: 'path' });
        }
        if (!db.objectStoreNames.contains(STORE_META)) {
          db.createObjectStore(STORE_META, { keyPath: 'key' });
        }
      };
      req.onsuccess = () => { _db = req.result; resolve(_db); };
      req.onerror = () => reject(req.error);
    });
  }

  function tx(storeName, mode) {
    return open().then((db) => db.transaction(storeName, mode).objectStore(storeName));
  }

  function putFile(path, data, mime) {
    return tx(STORE_FILES, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.put({ path, data, mime: mime || guessMime(path), updated: Date.now() });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function getFile(path) {
    return tx(STORE_FILES, 'readonly').then((store) => new Promise((resolve, reject) => {
      const req = store.get(path);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    }));
  }

  function deleteFile(path) {
    return tx(STORE_FILES, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.delete(path);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function listFiles() {
    return tx(STORE_FILES, 'readonly').then((store) => new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    }));
  }

  function clearFiles() {
    return tx(STORE_FILES, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function setMeta(key, value) {
    return tx(STORE_META, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.put({ key, value });
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function getMeta(key) {
    return tx(STORE_META, 'readonly').then((store) => new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ? req.result.value : null);
      req.onerror = () => reject(req.error);
    }));
  }

  function clearMeta() {
    return tx(STORE_META, 'readwrite').then((store) => new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    }));
  }

  function clearAll() {
    return Promise.all([clearFiles(), clearMeta()]);
  }

  // ---- Helpers ----
  function guessMime(path) {
    const lower = (path || '').toLowerCase();
    const ext = lower.split('.').pop();
    const map = {
      html: 'text/html', htm: 'text/html',
      css: 'text/css',
      js: 'application/javascript', mjs: 'application/javascript',
      json: 'application/json',
      png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
      gif: 'image/gif', svg: 'image/svg+xml', webp: 'image/webp',
      ico: 'image/x-icon', bmp: 'image/bmp',
      woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', eot: 'application/vnd.ms-fontobject',
      mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg', wav: 'audio/wav',
      pdf: 'application/pdf',
      txt: 'text/plain',
      xml: 'application/xml'
    };
    return map[ext] || 'application/octet-stream';
  }

  function isTextMime(mime) {
    if (!mime) return false;
    return mime.startsWith('text/') ||
      mime === 'application/javascript' ||
      mime === 'application/json' ||
      mime === 'application/xml' ||
      mime === 'image/svg+xml';
  }

  function blobToText(blob) {
    return blob.text();
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(blob);
    });
  }

  global.IVADb = {
    open, putFile, getFile, deleteFile, listFiles, clearFiles,
    setMeta, getMeta, clearMeta, clearAll,
    guessMime, isTextMime, blobToText, blobToDataUrl
  };
})(window);
