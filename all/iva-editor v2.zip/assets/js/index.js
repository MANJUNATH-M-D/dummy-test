/* ============================================================
   INDEX PAGE LOGIC
   ============================================================ */
(function () {
  'use strict';

  const DB = window.IVADb;
  const toast = window.IVAToast;
  const Preview = window.IVAPreview;

  // ---------- Elements ----------
  const el = {
    themeHost: document.getElementById('theme-toggle-host'),
    tabZip: document.getElementById('tab-zip'),
    tabFolder: document.getElementById('tab-folder'),
    panelZip: document.getElementById('panel-zip'),
    panelFolder: document.getElementById('panel-folder'),
    zipDropzone: document.getElementById('zip-dropzone'),
    zipInput: document.getElementById('zip-input'),
    folderDropzone: document.getElementById('folder-dropzone'),
    folderInput: document.getElementById('folder-input'),
    uploadView: document.getElementById('upload-view'),
    slidesView: document.getElementById('slides-view'),
    projectTitle: document.getElementById('project-title'),
    projectMeta: document.getElementById('project-meta'),
    slidesGrid: document.getElementById('slides-grid'),
    btnExport: document.getElementById('btn-export'),
    btnClear: document.getElementById('btn-clear'),
    overlay: document.getElementById('loading-overlay'),
    overlayText: document.getElementById('loading-text'),
    overlaySub: document.getElementById('loading-sub')
  };

  el.themeHost.appendChild(window.IVATheme.buildThemeToggleButton());

  function showOverlay(text, sub) {
    el.overlayText.textContent = text || 'Working…';
    el.overlaySub.textContent = sub || '';
    el.overlay.classList.add('active');
  }
  function updateOverlay(sub) { el.overlaySub.textContent = sub; }
  function hideOverlay() { el.overlay.classList.remove('active'); }

  // ---------- Tabs ----------
  function setTab(which) {
    [el.tabZip, el.tabFolder].forEach(t => t.classList.remove('active'));
    [el.panelZip, el.panelFolder].forEach(p => p.classList.remove('active'));
    if (which === 'folder') {
      el.tabFolder.classList.add('active');
      el.panelFolder.classList.add('active');
    } else {
      el.tabZip.classList.add('active');
      el.panelZip.classList.add('active');
    }
  }
  el.tabZip.addEventListener('click', () => setTab('zip'));
  el.tabFolder.addEventListener('click', () => setTab('folder'));

  // ---------- ZIP dropzone ----------
  el.zipDropzone.addEventListener('click', () => el.zipInput.click());
  el.zipInput.addEventListener('change', (e) => {
    if (e.target.files[0]) handleZipFile(e.target.files[0]);
    el.zipInput.value = '';
  });
  ['dragover', 'dragenter'].forEach(evt =>
    el.zipDropzone.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); el.zipDropzone.classList.add('dragover'); })
  );
  ['dragleave', 'drop'].forEach(evt =>
    el.zipDropzone.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); el.zipDropzone.classList.remove('dragover'); })
  );
  el.zipDropzone.addEventListener('drop', (e) => {
    const f = e.dataTransfer.files[0];
    if (f && /\.zip$/i.test(f.name)) handleZipFile(f);
    else toast({ type: 'error', title: 'Invalid file', message: 'Please drop a .zip file' });
  });

  // ---------- Folder dropzone ----------
  el.folderDropzone.addEventListener('click', () => el.folderInput.click());
  el.folderInput.addEventListener('change', (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length) handleFolderFiles(files);
    el.folderInput.value = '';
  });
  ['dragover', 'dragenter'].forEach(evt =>
    el.folderDropzone.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); el.folderDropzone.classList.add('dragover'); })
  );
  ['dragleave', 'drop'].forEach(evt =>
    el.folderDropzone.addEventListener(evt, e => { e.preventDefault(); e.stopPropagation(); el.folderDropzone.classList.remove('dragover'); })
  );
  el.folderDropzone.addEventListener('drop', async (e) => {
    const items = e.dataTransfer.items;
    if (!items || !items.length) return;
    const entries = [];
    for (let i = 0; i < items.length; i++) {
      const en = items[i].webkitGetAsEntry ? items[i].webkitGetAsEntry() : null;
      if (en) entries.push(en);
    }
    if (!entries.length) {
      toast({ type: 'error', title: 'Drop a folder', message: 'Drag a project folder onto this area' });
      return;
    }
    showOverlay('Reading folder…', 'Scanning files');
    const files = [];
    try {
      for (const en of entries) await readEntryRecursive(en, '', files);
      await handleFolderFiles(files);
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Read failed', message: err.message });
    }
  });

  function readEntryRecursive(entry, basePath, out) {
    return new Promise((resolve, reject) => {
      const path = basePath ? basePath + '/' + entry.name : entry.name;
      if (entry.isFile) {
        entry.file((file) => {
          file._relPath = path;
          out.push(file);
          resolve();
        }, reject);
      } else if (entry.isDirectory) {
        const reader = entry.createReader();
        const readAll = () => {
          reader.readEntries(async (entries) => {
            if (!entries.length) { resolve(); return; }
            try {
              for (const e of entries) await readEntryRecursive(e, path, out);
              readAll();
            } catch (err) { reject(err); }
          }, reject);
        };
        readAll();
      } else {
        resolve();
      }
    });
  }

  // ---------- MIME / detection ----------
  function getMime(filename) {
    const ext = (filename || '').split('.').pop().toLowerCase();
    const m = {
      html: 'text/html', htm: 'text/html', css: 'text/css',
      js: 'application/javascript', mjs: 'application/javascript',
      json: 'application/json', xml: 'application/xml',
      svg: 'image/svg+xml', png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg',
      gif: 'image/gif', webp: 'image/webp', ico: 'image/x-icon', bmp: 'image/bmp',
      mp4: 'video/mp4', webm: 'video/webm', mp3: 'audio/mpeg', wav: 'audio/wav',
      woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf',
      eot: 'application/vnd.ms-fontobject', pdf: 'application/pdf', txt: 'text/plain'
    };
    return m[ext] || 'application/octet-stream';
  }

  function detectRootFolder(paths) {
    if (!paths.length) return '';
    const tops = new Set();
    for (const p of paths) {
      const first = p.split('/')[0];
      if (first) tops.add(first);
    }
    if (tops.size === 1) {
      const root = Array.from(tops)[0];
      const directIndex = paths.includes(`${root}/index.html`);
      if (!directIndex) return root + '/';
    }
    return '';
  }

  function detectSlides(paths) {
    const slides = new Set();
    for (const path of paths) {
      const parts = path.split('/').filter(p => p);
      if (parts.length === 2 && parts[1] === 'index.html' && parts[0] !== 'shared') {
        slides.add(parts[0]);
      }
    }
    return Array.from(slides).sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
  }

  // ---------- ZIP / folder handlers ----------
  async function handleZipFile(file) {
    showOverlay('Extracting project…', file.name);
    try {
      await DB.clearAll();
      const zip = await JSZip.loadAsync(file);
      const allPaths = Object.keys(zip.files).filter(p => !zip.files[p].dir);
      const root = detectRootFolder(allPaths);
      let counter = 0;
      console.log('[IVA] ZIP upload — root prefix:', root, '— total files:', allPaths.length);
      for (const fullPath of allPaths) {
        counter++;
        const cleanPath = root ? fullPath.substring(root.length) : fullPath;
        if (!cleanPath) continue;
        const mime = getMime(cleanPath);
        const blob = await zip.files[fullPath].async('blob');
        const typed = new Blob([blob], { type: mime });
        await DB.putFile(cleanPath, typed, mime);

        // Diagnostic for index.html files
        if (/\/?index\.html$/i.test(cleanPath)) {
          try {
            const text = await typed.text();
            const sc = (text.match(/<script\b/gi) || []).length;
            const lk = (text.match(/<link\b/gi) || []).length;
            console.log('[IVA] Stored', cleanPath, '— size:', typed.size, 'bytes, scripts:', sc, ', links:', lk);
          } catch (e) {}
        }
        if (counter % 5 === 0) updateOverlay(`${counter} / ${allPaths.length} files`);
      }
      const cleanPaths = allPaths.map(p => root ? p.substring(root.length) : p);
      const slides = detectSlides(cleanPaths);
      const projectName = (root || file.name.replace(/\.zip$/i, '')).replace(/\/$/, '');
      await DB.setMeta('project', {
        name: projectName,
        slides: slides,
        uploadedAt: new Date().toISOString(),
        originalRoot: root
      });
      console.log('[IVA] ZIP upload complete. Slides detected:', slides);
      hideOverlay();
      toast({ type: 'success', title: 'Loaded', message: `${slides.length} slide${slides.length === 1 ? '' : 's'} ready` });
      await renderSlides();
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Extraction failed', message: err.message });
    }
  }

  async function handleFolderFiles(files) {
    if (!files.length) return;
    showOverlay('Importing folder…', files.length + ' files');
    try {
      await DB.clearAll();
      const paths = files.map(f => f._relPath || f.webkitRelativePath || f.name);
      const root = detectRootFolder(paths);
      let counter = 0;
      console.log('[IVA] Folder upload — root prefix:', root, '— total files:', files.length);
      for (const file of files) {
        counter++;
        const fullPath = file._relPath || file.webkitRelativePath || file.name;
        const cleanPath = root ? fullPath.substring(root.length) : fullPath;
        if (!cleanPath) continue;
        const mime = file.type || getMime(cleanPath);
        await DB.putFile(cleanPath, file, mime);

        // Diagnostic for index.html files — log script/link counts
        if (/\/?index\.html$/i.test(cleanPath)) {
          try {
            const text = await file.text();
            const sc = (text.match(/<script\b/gi) || []).length;
            const lk = (text.match(/<link\b/gi) || []).length;
            console.log('[IVA] Stored', cleanPath, '— size:', file.size, 'bytes, scripts:', sc, ', links:', lk);
          } catch (e) {}
        }
        if (counter % 5 === 0) updateOverlay(`${counter} / ${files.length} files`);
      }
      const cleanPaths = paths.map(p => root ? p.substring(root.length) : p);
      const slides = detectSlides(cleanPaths);
      const projectName = root ? root.replace(/\/$/, '') : 'iva-project';
      await DB.setMeta('project', {
        name: projectName,
        slides: slides,
        uploadedAt: new Date().toISOString(),
        originalRoot: root
      });
      console.log('[IVA] Folder upload complete. Slides detected:', slides);
      hideOverlay();
      toast({ type: 'success', title: 'Loaded', message: `${slides.length} slide${slides.length === 1 ? '' : 's'} ready` });
      await renderSlides();
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Import failed', message: err.message });
    }
  }

  async function rescanSlides() {
    const files = await DB.listFiles();
    const paths = files.map(f => f.path);
    return detectSlides(paths);
  }

  // ---------- Render slides ----------
  async function renderSlides() {
    const project = await DB.getMeta('project');
    if (!project) {
      el.uploadView.classList.remove('hidden');
      el.slidesView.classList.add('hidden');
      return;
    }
    const slides = await rescanSlides();
    project.slides = slides;
    await DB.setMeta('project', project);

    el.uploadView.classList.add('hidden');
    el.slidesView.classList.remove('hidden');
    el.projectTitle.textContent = project.name;
    el.projectMeta.textContent = `${slides.length} slides · ${new Date(project.uploadedAt).toLocaleString()}`;

    el.slidesGrid.innerHTML = '';
    if (!slides.length) {
      el.slidesGrid.innerHTML = '<div class="empty-state">No slides detected. Each slide folder needs an <code>index.html</code>.</div>';
      return;
    }
    for (const slide of slides) {
      const card = createSlideCard(slide);
      el.slidesGrid.appendChild(card);
      renderThumbnail(slide, card);
    }
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function createSlideCard(slide) {
    const card = document.createElement('div');
    card.className = 'slide-card';
    card.dataset.slide = slide;
    card.innerHTML = `
      <div class="slide-thumbnail">
        <div class="spinner"></div>
      </div>
      <div class="slide-info">
        <div class="slide-name-row">
          <input class="slide-name" value="${escapeHtml(slide)}" spellcheck="false" />
          <button class="slide-rename" title="Click name to rename">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/>
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>
            </svg>
          </button>
          <span class="slide-tag">HTML</span>
        </div>
        <div class="slide-path">${escapeHtml(slide)}/index.html</div>
      </div>
      <div class="slide-actions">
        <button class="btn btn-sm" data-act="preview" title="Open preview in new tab">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
          Preview
        </button>
        <button class="btn btn-sm" data-act="download" title="Download this slide as standalone HTML">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
          Download
        </button>
        <button class="btn btn-sm btn-primary" data-act="edit">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
          Edit
        </button>
      </div>
    `;

    // Edit → new tab
    card.querySelector('[data-act="edit"]').addEventListener('click', () => {
      window.open('editor.html?slide=' + encodeURIComponent(card.dataset.slide), '_blank');
    });
    // Preview → new tab
    card.querySelector('[data-act="preview"]').addEventListener('click', async () => {
      await openPreviewInNewTab(card.dataset.slide);
    });
    // Download → standalone HTML
    card.querySelector('[data-act="download"]').addEventListener('click', async () => {
      await downloadSlide(card.dataset.slide);
    });

    // Inline rename
    const nameInput = card.querySelector('.slide-name');
    const renameBtn = card.querySelector('.slide-rename');
    let originalName = slide;
    renameBtn.addEventListener('click', () => { nameInput.focus(); nameInput.select(); });
    nameInput.addEventListener('focus', () => { originalName = nameInput.value; });
    nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); nameInput.blur(); }
      else if (e.key === 'Escape') { nameInput.value = originalName; nameInput.blur(); }
    });
    nameInput.addEventListener('blur', async () => {
      const newName = nameInput.value.trim();
      if (!newName || newName === originalName) { nameInput.value = originalName; return; }
      if (!/^[A-Za-z0-9_\-. ]+$/.test(newName)) {
        toast({ type: 'error', title: 'Invalid name', message: 'Use letters, numbers, spaces, dashes, underscores, dots' });
        nameInput.value = originalName;
        return;
      }
      const existing = await rescanSlides();
      if (existing.some(s => s !== originalName && s.toLowerCase() === newName.toLowerCase())) {
        toast({ type: 'error', title: 'Name taken', message: `"${newName}" already exists` });
        nameInput.value = originalName;
        return;
      }
      try {
        await renameSlideFolder(originalName, newName);
        card.dataset.slide = newName;
        toast({ type: 'success', title: 'Renamed', message: `${originalName} → ${newName}` });
        await renderSlides();
      } catch (err) {
        console.error(err);
        toast({ type: 'error', title: 'Rename failed', message: err.message });
        nameInput.value = originalName;
      }
    });

    return card;
  }

  async function renameSlideFolder(oldName, newName) {
    const all = await DB.listFiles();
    const oldPrefix = oldName + '/';
    const newPrefix = newName + '/';
    for (const f of all) {
      if (f.path.startsWith(oldPrefix)) {
        const newPath = newPrefix + f.path.substring(oldPrefix.length);
        await DB.putFile(newPath, f.data, f.mime);
        await DB.deleteFile(f.path);
      }
    }
  }

  // ---------- Thumbnails ----------
  async function renderThumbnail(slide, card) {
    try {
      // Use the shared self-contained builder so shared/ resolves correctly.
      // inlineJs: true means external scripts are inlined into the HTML — every
      // <script> tag from the original is therefore present in the thumbnail source.
      // (The sandbox attribute below still prevents them from executing — perfect for a
      // static visual preview while keeping the tags visible if you inspect the iframe.)
      const html = await Preview.buildSelfContainedHtml(slide + '/index.html', { inlineJs: true });
      const thumb = card.querySelector('.slide-thumbnail');
      thumb.innerHTML = '';
      const iframe = document.createElement('iframe');
      iframe.setAttribute('sandbox', 'allow-same-origin');
      iframe.srcdoc = html;
      thumb.appendChild(iframe);

      const updateScale = () => {
        const w = thumb.clientWidth;
        const h = thumb.clientHeight;
        if (!w || !h) return;
        // Detect slide width based on body or html offsetWidth (default to 1366 — iPad Pro 12.9 landscape)
        let slideW = 1366, slideH = 1024;
        try {
          const idoc = iframe.contentDocument;
          if (idoc) {
            const w2 = idoc.body && idoc.body.scrollWidth;
            const h2 = idoc.body && idoc.body.scrollHeight;
            if (w2 && w2 > 200) slideW = w2;
            if (h2 && h2 > 200) slideH = h2;
          }
        } catch (e) {}
        // Set iframe to slide's natural size
        iframe.style.width = slideW + 'px';
        iframe.style.height = slideH + 'px';
        const scale = Math.min(w / slideW, h / slideH);
        iframe.style.transform = 'scale(' + scale + ')';
      };
      iframe.addEventListener('load', () => {
        // Multiple delayed attempts to catch late-loading images/fonts
        updateScale();
        setTimeout(updateScale, 200);
        setTimeout(updateScale, 800);
      });
      window.addEventListener('resize', updateScale);
      // Initial scale (uses default 1366×1024 until iframe reports its real size)
      updateScale();
    } catch (err) {
      console.warn('Thumb failed for', slide, err);
      const thumb = card.querySelector('.slide-thumbnail');
      thumb.innerHTML = `<div class="placeholder">${escapeHtml(slide)}</div>`;
    }
  }

  // ---------- Preview in new tab ----------
  async function openPreviewInNewTab(slide) {
    showOverlay('Building preview…', slide);
    try {
      const html = await Preview.buildSelfContainedHtml(slide + '/index.html', { inlineJs: true });
      const blob = new Blob([html], { type: 'text/html' });
      const url = URL.createObjectURL(blob);
      const win = window.open(url, '_blank');
      if (!win) {
        hideOverlay();
        toast({ type: 'error', title: 'Popup blocked', message: 'Allow popups for preview' });
        return;
      }
      setTimeout(() => URL.revokeObjectURL(url), 60000);
      hideOverlay();
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Preview failed', message: err.message });
    }
  }

  // ---------- Download single slide ----------
  async function downloadSlide(slide) {
    showOverlay('Preparing download…', slide);
    try {
      const html = await Preview.buildSelfContainedHtml(slide + '/index.html', { inlineJs: true });
      const blob = new Blob([html], { type: 'text/html' });
      const filename = slide + '.html';
      await saveBlob(blob, filename, 'text/html');
      hideOverlay();
      toast({ type: 'success', title: 'Downloaded', message: filename });
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Download failed', message: err.message });
    }
  }

  // ---------- Generic blob saver (File System Access API → native fallback) ----------
  async function saveBlob(blob, filename, mime) {
    // Determine extension/description for picker
    const ext = filename.includes('.') ? '.' + filename.split('.').pop().toLowerCase() : '';
    const desc = mime === 'application/zip' ? 'ZIP archive'
               : mime === 'text/html'        ? 'HTML file'
               : 'File';

    if (window.showSaveFilePicker && window.isSecureContext) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: filename,
          types: ext ? [{ description: desc, accept: { [mime]: [ext] } }] : []
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        return;
      } catch (err) {
        if (err && err.name === 'AbortError') throw err;
        console.warn('showSaveFilePicker failed, fallback', err);
      }
    }
    // Fallback: native anchor download
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.rel = 'noopener';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // ---------- Export ZIP ----------
  el.btnExport.addEventListener('click', exportZip);
  async function exportZip() {
    showOverlay('Building ZIP…', 'Packaging files');
    try {
      const project = await DB.getMeta('project');
      const files = await DB.listFiles();
      if (!files.length) throw new Error('No files to export');

      const zip = new JSZip();
      const rootPrefix = project?.originalRoot || '';
      for (const f of files) {
        zip.file(rootPrefix + f.path, f.data, {
          date: new Date(f.updated || Date.now()),
          createFolders: true
        });
      }
      const blob = await zip.generateAsync({
        type: 'blob',
        mimeType: 'application/zip',
        compression: 'DEFLATE',
        compressionOptions: { level: 6 },
        platform: 'DOS',
        comment: 'IVA Editor export'
      });

      const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
      const baseName = (project?.name || 'iva-project').replace(/[^A-Za-z0-9_\-]/g, '_');
      const filename = `${baseName}-${ts}.zip`;

      try {
        await saveBlob(blob, filename, 'application/zip');
      } catch (err) {
        if (err && err.name === 'AbortError') { hideOverlay(); return; }
        throw err;
      }
      hideOverlay();
      toast({
        type: 'success',
        title: 'Export ready',
        message: 'If extraction shows a warning, right-click ZIP → Properties → Unblock, then extract.',
        duration: 6000
      });
    } catch (err) {
      console.error(err);
      hideOverlay();
      toast({ type: 'error', title: 'Export failed', message: err.message });
    }
  }

  // ---------- Clear ----------
  el.btnClear.addEventListener('click', async () => {
    if (!confirm('Clear the current project? Export first if you need a copy.')) return;
    await DB.clearAll();
    el.uploadView.classList.remove('hidden');
    el.slidesView.classList.add('hidden');
    toast({ type: 'info', title: 'Cleared', message: 'Project removed from browser storage' });
  });

  // Refresh on tab focus (e.g. after editor save in another tab)
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) renderSlides();
  });

  // Initial render
  renderSlides();
})();
