/* ============================================================
   Self-contained HTML builder
   Bundles a slide's index.html with ALL referenced assets inlined
   (CSS as <style>, images as data: URIs, JS as inline <script>).
   Works regardless of whether the slide uses `../shared/...`
   or `shared/...` (root-relative) path conventions.
   ============================================================ */
(function (global) {
  'use strict';

  const DB = global.IVADb;

  function normalizePath(baseFile, href) {
    if (!href) return '';
    if (/^(https?:|\/\/|data:|blob:)/i.test(href)) return href;
    const dir = baseFile.includes('/') ? baseFile.substring(0, baseFile.lastIndexOf('/') + 1) : '';
    const combined = dir + href;
    const parts = combined.split('/');
    const stack = [];
    for (const p of parts) {
      if (p === '' || p === '.') continue;
      if (p === '..') stack.pop();
      else stack.push(p);
    }
    return stack.join('/');
  }

  // Smart resolver: try the standard relative interpretation,
  // then fall back to project-root interpretation.
  async function resolveAsset(baseFile, href) {
    if (!href || /^(https?:|\/\/|data:|blob:)/i.test(href)) return null;

    // 1. Standard: relative to base file
    const relPath = normalizePath(baseFile, href);
    if (await DB.getFile(relPath)) return relPath;

    // 2. Strip any ../ prefixes and try as root-relative
    const stripped = href.replace(/^(\.\.\/)+/, '').replace(/^\.\//, '');
    if (stripped !== relPath) {
      if (await DB.getFile(stripped)) return stripped;
    }

    return null;
  }

  async function rewriteCssUrlsInline(cssText, basePath) {
    const matches = [...cssText.matchAll(/url\(['"]?([^'")]+)['"]?\)/g)];
    if (!matches.length) return cssText;
    let result = cssText;
    for (const m of matches) {
      const u = m[1];
      if (/^(https?:|\/\/|data:|blob:)/i.test(u) || u.startsWith('#')) continue;
      const resolved = await resolveAsset(basePath, u);
      if (!resolved) continue;
      const r = await DB.getFile(resolved);
      if (!r) continue;
      try {
        const dataUrl = await DB.blobToDataUrl(r.data);
        result = result.split(m[0]).join(`url("${dataUrl}")`);
      } catch (e) {}
    }
    return result;
  }

  async function buildSelfContainedHtml(indexPath, opts) {
    opts = Object.assign({ inlineJs: true }, opts || {});
    const rec = await DB.getFile(indexPath);
    if (!rec) throw new Error('Not found: ' + indexPath);
    const htmlText = await DB.blobToText(rec.data);
    const doc = new DOMParser().parseFromString(htmlText, 'text/html');

    // Inline <link rel="stylesheet">
    for (const link of [...doc.querySelectorAll('link[rel="stylesheet"][href]')]) {
      const href = link.getAttribute('href');
      if (/^(https?:|\/\/|data:|blob:)/i.test(href)) continue;
      const resolved = await resolveAsset(indexPath, href);
      if (!resolved) continue;       // can't find — leave the tag alone, don't strip
      const r = await DB.getFile(resolved);
      if (!r) continue;
      const cssText = await DB.blobToText(r.data);
      const styleEl = doc.createElement('style');
      styleEl.setAttribute('data-from', href);
      styleEl.textContent = await rewriteCssUrlsInline(cssText, resolved);
      link.replaceWith(styleEl);
    }

    // Existing <style> url() refs
    for (const s of doc.querySelectorAll('style')) {
      if (!s.textContent) continue;
      s.textContent = await rewriteCssUrlsInline(s.textContent, indexPath);
    }

    // Inline images
    for (const img of doc.querySelectorAll('img[src]')) {
      const src = img.getAttribute('src');
      if (/^(https?:|\/\/|data:|blob:)/i.test(src)) continue;
      const resolved = await resolveAsset(indexPath, src);
      if (!resolved) continue;
      const r = await DB.getFile(resolved);
      if (r) {
        try { img.setAttribute('src', await DB.blobToDataUrl(r.data)); } catch (e) {}
      }
    }

    // srcset
    for (const el of doc.querySelectorAll('[srcset]')) {
      const ss = el.getAttribute('srcset');
      const parts = ss.split(',').map(p => p.trim());
      const newParts = await Promise.all(parts.map(async (part) => {
        const tokens = part.split(/\s+/);
        const u = tokens[0];
        if (/^(https?:|\/\/|data:|blob:)/i.test(u)) return part;
        const resolved = await resolveAsset(indexPath, u);
        if (!resolved) return part;
        const r = await DB.getFile(resolved);
        if (!r) return part;
        try {
          const dataUrl = await DB.blobToDataUrl(r.data);
          return [dataUrl, ...tokens.slice(1)].join(' ');
        } catch (e) { return part; }
      }));
      el.setAttribute('srcset', newParts.join(', '));
    }

    // Inline style attribute url()
    for (const node of doc.querySelectorAll('[style*="url("]')) {
      node.setAttribute('style', await rewriteCssUrlsInline(node.getAttribute('style') || '', indexPath));
    }

    // Scripts — preserve every <script> tag. We inline external ones when we can (so they
    // execute in standalone preview), but if a script can't be resolved we LEAVE it as-is
    // rather than removing it, so the HTML structure is never silently mutated.
    for (const sc of [...doc.querySelectorAll('script[src]')]) {
      const src = sc.getAttribute('src');
      if (/^(https?:|\/\/|data:|blob:)/i.test(src)) continue;   // external — leave alone
      if (!opts.inlineJs) continue;                              // thumbnail mode — keep tag, don't try to inline
      const resolved = await resolveAsset(indexPath, src);
      if (!resolved) continue;                                   // can't find file — keep original src, don't remove
      const r = await DB.getFile(resolved);
      if (!r) continue;
      const code = await DB.blobToText(r.data);
      const inline = doc.createElement('script');
      inline.textContent = code;
      sc.replaceWith(inline);
    }

    return '<!DOCTYPE html>' + doc.documentElement.outerHTML;
  }

  global.IVAPreview = {
    buildSelfContainedHtml,
    resolveAsset,
    normalizePath,
    rewriteCssUrlsInline
  };
})(window);
