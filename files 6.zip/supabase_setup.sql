-- ============================================================
--  JSW Paints — Supabase database setup  (with login security)
--  HOW TO USE:
--  1. In your Supabase project, open the left menu -> "SQL Editor"
--  2. Click "New query"
--  3. Copy EVERYTHING in this file and paste it into the editor
--  4. Click the green "Run" button
--  You should see "Success. No rows returned." -> that means it worked.
--
--  AFTER running this, create your login:
--  Left menu -> Authentication -> Users -> "Add user" ->
--  enter your email + a password -> Create user.
--  Use that email/password on the app's login screen.
-- ============================================================

-- ---------- PRODUCTS ----------
create table if not exists products (
  barcode   text primary key,
  name      text not null,
  cat       text,
  mrp       numeric default 0,
  dealer    numeric default 0,
  custdisc  numeric default 0,
  cost      numeric default 0,
  price     numeric default 0,
  gst       numeric default 18,
  qty       integer default 0,
  low       integer default 5,
  created_at timestamptz default now()
);
-- if products table already exists from before, add the new columns:
alter table products add column if not exists mrp      numeric default 0;
alter table products add column if not exists dealer   numeric default 0;
alter table products add column if not exists custdisc numeric default 0;

-- ---------- CUSTOMERS ----------
create table if not exists customers (
  mobile    text primary key,
  name      text not null,
  orders    integer default 0,
  spent     numeric default 0,
  last      bigint default 0
);

-- ---------- REFERRAL PERSONS ----------
create table if not exists referrals (
  name      text primary key
);

-- ---------- STOCK MOVEMENTS ----------
create table if not exists movements (
  id        bigint generated always as identity primary key,
  ts        bigint,
  barcode   text,
  name      text,
  type      text,
  qty       integer,
  note      text
);

-- ---------- BILLS ----------
create table if not exists bills (
  no         integer primary key,
  ts         bigint,
  custmobile text,
  custname   text,
  type       text,
  items      jsonb,
  subtotal   numeric,
  discount   numeric,
  gstamt     numeric,
  total      numeric,
  refer      text
);

-- ---------- BILL COUNTER ----------
create table if not exists counters (
  id        text primary key,
  value     integer
);
insert into counters (id, value) values ('billSeq', 1)
on conflict (id) do nothing;

-- ============================================================
--  SECURITY — only LOGGED-IN users can read/write.
--  Anyone without a valid login is fully blocked.
-- ============================================================
alter table products  enable row level security;
alter table customers enable row level security;
alter table referrals enable row level security;
alter table movements enable row level security;
alter table bills     enable row level security;
alter table counters  enable row level security;

do $$
declare t text;
begin
  foreach t in array array['products','customers','referrals','movements','bills','counters']
  loop
    -- remove any old open policies from earlier setup
    execute format('drop policy if exists "allow all %1$s" on %1$s;', t);
    execute format('drop policy if exists "auth all %1$s" on %1$s;', t);
    -- new policy: only authenticated users
    execute format('create policy "auth all %1$s" on %1$s for all to authenticated using (true) with check (true);', t);
  end loop;
end $$;
